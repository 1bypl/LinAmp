"""Analizator widma — prawdziwe pasma częstotliwości z odtwarzanego dźwięku.

Dane PCM trafiają tutaj z silnika audio (QAudioBufferOutput), a następnie
są przeliczane na widmo za pomocą szybkiej transformaty Fouriera (FFT).
"""

from __future__ import annotations

import time

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QSizePolicy, QWidget

from ..theme import BORDER

try:  # numpy jest w wymaganiach, ale aplikacja poradzi sobie i bez niego
    import numpy as np

    HAVE_NUMPY = True
except Exception:  # pragma: no cover
    np = None  # type: ignore[assignment]
    HAVE_NUMPY = False


class SpectrumWidget(QWidget):
    """Słupki widma z opadającymi „czapkami" szczytów."""

    BANDS = 56

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setMinimumHeight(96)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self._buffer = np.zeros(0, dtype=np.float32) if HAVE_NUMPY else None
        self._sample_rate = 48000
        self._levels = np.zeros(self.BANDS) if HAVE_NUMPY else [0.0] * self.BANDS
        self._peaks = np.zeros(self.BANDS) if HAVE_NUMPY else [0.0] * self.BANDS
        self._last_data = 0.0
        self._playing = False
        self._supported = True
        self._time = 0.0

        self._timer = QTimer(self)
        self._timer.setInterval(33)  # ~30 klatek na sekundę
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    # --- dane wejściowe -----------------------------------------------------
    def set_supported(self, supported: bool) -> None:
        """Czy backend potrafi dostarczyć próbki (jeśli nie — animacja dekoracyjna)."""
        self._supported = bool(supported)

    def set_playing(self, playing: bool) -> None:
        self._playing = bool(playing)

    def set_samples(self, payload) -> None:
        if not HAVE_NUMPY or payload is None:
            return
        try:
            samples, rate = payload
        except (TypeError, ValueError):
            samples, rate = payload, 48000
        if samples is None or len(samples) == 0:
            return

        self._sample_rate = int(rate) if rate else self._sample_rate
        chunk = np.asarray(samples, dtype=np.float32)
        self._buffer = np.concatenate((self._buffer, chunk))[-16384:]
        self._last_data = time.monotonic()

    # --- obliczenia ---------------------------------------------------------
    def _compute(self):
        window = 4096
        data = self._buffer[-window:]
        if data.size < window:
            data = np.pad(data, (window - data.size, 0))

        hann = np.hanning(window)
        spectrum = np.abs(np.fft.rfft(data * hann)) / (window / 2.0)
        freqs = np.fft.rfftfreq(window, 1.0 / self._sample_rate)

        top = min(16000.0, self._sample_rate * 0.45)
        edges = np.geomspace(35.0, max(60.0, top), self.BANDS + 1)
        indices = np.searchsorted(freqs, edges)

        bands = np.zeros(self.BANDS, dtype=np.float32)
        for i in range(self.BANDS):
            start = int(indices[i])
            end = max(start + 1, int(indices[i + 1]))
            segment = spectrum[start:end]
            if segment.size:
                bands[i] = float(segment.max())

        decibels = 20.0 * np.log10(bands + 1e-6)
        levels = np.clip((decibels + 78.0) / 60.0, 0.0, 1.0)
        return levels**0.85

    def _synthetic(self):
        """Delikatna animacja, gdy backend nie udostępnia próbek."""
        self._time += 0.033
        index = np.arange(self.BANDS)
        base = (
            0.16
            + 0.14 * np.sin(self._time * 2.4 + index * 0.33)
            + 0.07 * np.sin(self._time * 5.3 + index * 0.87)
        )
        return np.clip(base + np.random.random(self.BANDS) * 0.10, 0.02, 1.0)

    def _tick(self) -> None:
        if not HAVE_NUMPY:
            return
        now = time.monotonic()
        has_recent_data = (
            self._buffer is not None
            and self._buffer.size > 0
            and (now - self._last_data) < 0.4
        )

        if has_recent_data:
            levels = self._compute()
        elif self._playing and not self._supported:
            levels = self._synthetic()
        else:
            levels = np.zeros(self.BANDS, dtype=np.float32)

        rising = levels > self._levels
        self._levels[rising] = (
            self._levels[rising] + (levels[rising] - self._levels[rising]) * 0.65
        )
        self._levels[~rising] *= 0.90
        self._peaks = np.maximum(self._levels, self._peaks - 0.012)

        self.update()

    # --- rysowanie ----------------------------------------------------------
    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath()
        path.addRoundedRect(rect, 13, 13)

        background = QLinearGradient(rect.topLeft(), rect.bottomLeft())
        background.setColorAt(0.0, QColor("#141821"))
        background.setColorAt(1.0, QColor("#0e1116"))
        painter.fillPath(path, background)
        painter.setPen(QPen(QColor(BORDER), 1))
        painter.drawPath(path)
        painter.setClipPath(path)

        inner = rect.adjusted(16, 14, -16, -14)
        if inner.width() <= 0 or inner.height() <= 0:
            return

        count = self.BANDS
        gap = 4.0 if inner.width() > 480 else 3.0
        bar_width = (inner.width() - gap * (count - 1)) / count
        if bar_width <= 0.5:
            return

        baseline = inner.bottom()
        painter.setPen(QPen(QColor(255, 255, 255, 16), 1))
        painter.drawLine(inner.left(), baseline, inner.right(), baseline)

        levels = self._levels
        peaks = self._peaks

        for i in range(count):
            level = float(levels[i])
            if level <= 0.004:
                continue

            x = inner.left() + i * (bar_width + gap)
            height = max(2.0, level * inner.height())
            bar = QRectF(x, baseline - height, bar_width, height)

            gradient = QLinearGradient(0, bar.top(), 0, bar.bottom())
            gradient.setColorAt(0.0, QColor("#8dffc0"))
            gradient.setColorAt(0.45, QColor("#1ed760"))
            gradient.setColorAt(1.0, QColor("#0f9f4c"))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(gradient)
            radius = min(2.5, bar_width / 2.0)
            painter.drawRoundedRect(bar, radius, radius)

            peak = float(peaks[i])
            if peak > 0.03:
                peak_y = baseline - peak * inner.height() - 3.0
                painter.setBrush(QColor(200, 255, 220, 210))
                painter.drawRoundedRect(QRectF(x, peak_y, bar_width, 2.0), 1.0, 1.0)
