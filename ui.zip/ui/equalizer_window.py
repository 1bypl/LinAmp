"""Okno 10-pasmowego korektora graficznego."""

from __future__ import annotations

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from ..config import Config
from ..equalizer import EQ_FREQUENCIES, EQ_PRESETS, Equalizer
from ..i18n import tr
from ..theme import MUTED


class EqualizerWindow(QDialog):
    """Suwaki 31 Hz – 16 kHz, presety i przedwzmacniacz."""

    def __init__(self, equalizer: Equalizer, config: Config, parent=None) -> None:
        super().__init__(parent)
        self._eq = equalizer
        self._config = config
        self._updating = False
        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(250)
        self._save_timer.timeout.connect(self._save_config)

        self.setWindowTitle(tr("Korektor"))
        self.setMinimumWidth(720)
        self.setObjectName("EqualizerWindow")

        self._build_ui()
        self._load_values()

    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(22, 18, 22, 18)
        outer.setSpacing(14)

        title = QLabel(tr("Korektor graficzny (10 pasm)"), self)
        title.setObjectName("SectionTitle")
        outer.addWidget(title)

        subtitle = QLabel(
            tr("Ustawienia działają od razu. Gdy korektor jest wyłączony, "
               "program gra dokładnie tak jak wcześniej."),
            self,
        )
        subtitle.setStyleSheet(f"color: {MUTED};")
        subtitle.setWordWrap(True)
        outer.addWidget(subtitle)

        self.chk_enabled = QCheckBox(tr("Włącz korektor"), self)
        self.chk_enabled.toggled.connect(self._on_enabled_toggled)
        outer.addWidget(self.chk_enabled)

        line = QFrame(self)
        line.setFrameShape(QFrame.Shape.HLine)
        line.setFrameShadow(QFrame.Shadow.Sunken)
        outer.addWidget(line)

        preset_row = QHBoxLayout()
        preset_row.setSpacing(10)
        preset_row.addWidget(QLabel(tr("Preset"), self))
        self.cmb_preset = QComboBox(self)
        self.cmb_preset.setMinimumWidth(190)
        self.cmb_preset.addItem(tr("Niestandardowy"))
        for name in EQ_PRESETS:
            self.cmb_preset.addItem(tr(name))
        self.cmb_preset.currentIndexChanged.connect(self._on_preset_changed)
        preset_row.addWidget(self.cmb_preset)
        preset_row.addStretch(1)
        self.btn_reset = QPushButton(tr("Reset"), self)
        self.btn_reset.clicked.connect(self._reset)
        preset_row.addWidget(self.btn_reset)
        outer.addLayout(preset_row)

        preamp_row = QHBoxLayout()
        preamp_row.setSpacing(10)
        preamp_row.addWidget(QLabel(tr("Preamp"), self))
        self.sld_preamp = QSlider(Qt.Orientation.Horizontal, self)
        self.sld_preamp.setRange(-12, 12)
        self.sld_preamp.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.sld_preamp.setTickInterval(3)
        self.sld_preamp.valueChanged.connect(self._on_preamp_changed)
        preamp_row.addWidget(self.sld_preamp, 1)
        self.lbl_preamp = QLabel("0 dB", self)
        self.lbl_preamp.setMinimumWidth(52)
        self.lbl_preamp.setAlignment(
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        )
        preamp_row.addWidget(self.lbl_preamp)
        outer.addLayout(preamp_row)

        bands = QWidget(self)
        grid = QGridLayout(bands)
        grid.setContentsMargins(0, 4, 0, 0)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(6)

        self._sliders: list[QSlider] = []
        self._value_labels: list[QLabel] = []
        for column, frequency in enumerate(EQ_FREQUENCIES):
            value_label = QLabel("0", bands)
            value_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            value_label.setStyleSheet(f"color: {MUTED};")
            slider = QSlider(Qt.Orientation.Vertical, bands)
            slider.setRange(-12, 12)
            slider.setValue(0)
            slider.setTickPosition(QSlider.TickPosition.TicksBothSides)
            slider.setTickInterval(3)
            slider.setMinimumHeight(190)
            slider.valueChanged.connect(
                lambda value, index=column: self._on_band_changed(index, value)
            )
            freq_label = QLabel(self._format_frequency(frequency), bands)
            freq_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            freq_label.setStyleSheet(f"color: {MUTED}; font-size: 11px;")

            grid.addWidget(value_label, 0, column)
            grid.addWidget(slider, 1, column)
            grid.addWidget(freq_label, 2, column)
            self._sliders.append(slider)
            self._value_labels.append(value_label)

        outer.addWidget(bands, 1)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close, self)
        buttons.rejected.connect(self.close)
        buttons.button(QDialogButtonBox.StandardButton.Close).setText(tr("Zamknij"))
        outer.addWidget(buttons)

        if not self._eq.available:
            self.chk_enabled.setEnabled(False)
            self.chk_enabled.setToolTip(tr("Korektor jest niedostępny na tym systemie."))

    # ------------------------------------------------------------------
    def _load_values(self) -> None:
        gains = self._config.get("eq_gains", [0] * len(EQ_FREQUENCIES))
        if not isinstance(gains, list):
            gains = [0] * len(EQ_FREQUENCIES)
        values = [int(max(-12, min(12, int(value)))) for value in gains]
        while len(values) < len(EQ_FREQUENCIES):
            values.append(0)
        preamp = int(max(-12, min(12, int(self._config.get("eq_preamp", 0)))))

        self._updating = True
        for slider, value in zip(self._sliders, values):
            slider.setValue(value)
        self.sld_preamp.setValue(preamp)
        self._updating = False

        self._update_labels()
        self._eq.set_gains(values)
        self._eq.set_preamp(preamp)
        self._sync_preset_combo()

        enabled = bool(self._config.get("eq_enabled", False))
        self.chk_enabled.setChecked(enabled and self._eq.available)
        if enabled and not self._eq.available:
            self._config.set("eq_enabled", False)
            self._save_config()

    def _update_labels(self) -> None:
        for slider, label in zip(self._sliders, self._value_labels):
            label.setText(self._format_gain(slider.value()))
        self.lbl_preamp.setText(f"{self._format_gain(self.sld_preamp.value())} dB")

    @staticmethod
    def _format_gain(value: int) -> str:
        return f"+{value}" if value > 0 else str(value)

    @staticmethod
    def _format_frequency(frequency: int) -> str:
        if frequency >= 1000:
            return f"{frequency // 1000} kHz"
        return f"{frequency} Hz"

    def _gains(self) -> list[int]:
        return [slider.value() for slider in self._sliders]

    def _sync_preset_combo(self) -> None:
        gains = tuple(self._gains())
        match = next(
            (name for name, values in EQ_PRESETS.items() if tuple(int(v) for v in values) == gains),
            None,
        )
        self._updating = True
        self.cmb_preset.setCurrentIndex(
            0 if match is None else list(EQ_PRESETS).index(match) + 1
        )
        self._updating = False

    # ------------------------------------------------------------------
    def _on_enabled_toggled(self, enabled: bool) -> None:
        if self._updating:
            return
        if enabled and not self._eq.set_enabled(True):
            self._updating = True
            self.chk_enabled.setChecked(False)
            self._updating = False
            return
        if not enabled:
            self._eq.set_enabled(False)
        self._config.set("eq_enabled", bool(enabled))
        self._save_timer.start()

    def _on_band_changed(self, index: int, value: int) -> None:
        if self._updating:
            return
        self._value_labels[index].setText(self._format_gain(value))
        self._eq.set_gains(self._gains())
        self._sync_preset_combo()
        self._config.set("eq_gains", self._gains())
        self._save_timer.start()

    def _on_preamp_changed(self, value: int) -> None:
        if self._updating:
            return
        self.lbl_preamp.setText(f"{self._format_gain(value)} dB")
        self._eq.set_preamp(value)
        self._config.set("eq_preamp", int(value))
        self._save_timer.start()

    def _on_preset_changed(self, index: int) -> None:
        if self._updating or index <= 0:
            return
        name = list(EQ_PRESETS)[index - 1]
        values = [int(value) for value in EQ_PRESETS[name]]
        self._updating = True
        for slider, value in zip(self._sliders, values):
            slider.setValue(value)
        self._updating = False
        self._update_labels()
        self._eq.set_gains(values)
        self._config.set("eq_gains", values)
        self._save_timer.start()

    def _reset(self) -> None:
        self.cmb_preset.setCurrentIndex(1)  # "Płaski"
        self.sld_preamp.setValue(0)

    def _save_config(self) -> None:
        self._config.set("eq_gains", self._gains())
        self._config.set("eq_preamp", int(self.sld_preamp.value()))
        self._config.set("eq_enabled", bool(self.chk_enabled.isChecked()))
        self._config.save()

    # ------------------------------------------------------------------
    def showEvent(self, event) -> None:  # noqa: N802
        # Okno mogło zostać otwarte po zmianie ustawień w innym miejscu.
        self._updating = True
        self.chk_enabled.setChecked(
            bool(self._config.get("eq_enabled", False)) and self._eq.available
        )
        self._updating = False
        super().showEvent(event)
