"""Elementy interfejsu: przyciski, suwaki, okładka, etykiety czasu."""
