"""Zadania wykonywane w tle (czytanie tagów i okładek).

Dzięki nim dodanie folderu z tysiącami plików nie zamraża interfejsu.
"""

from __future__ import annotations

from PySide6.QtCore import QObject, QRunnable, Signal

from ..metadata import read_cover, read_track


class WorkerSignals(QObject):
    metadataBatch = Signal(list)       # list[TrackInfo]
    coverReady = Signal(str, bytes, str)  # ścieżka, dane, typ MIME
    finished = Signal()


class MetadataTask(QRunnable):
    """Czyta metadane partiami, żeby interfejs odświeżał się na bieżąco."""

    BATCH_SIZE = 30

    def __init__(self, paths: list[str], signals: WorkerSignals) -> None:
        super().__init__()
        self._paths = list(paths)
        self._signals = signals
        self.setAutoDelete(True)

    def run(self) -> None:
        batch = []
        for path in self._paths:
            try:
                batch.append(read_track(path))
            except Exception:
                continue
            if len(batch) >= self.BATCH_SIZE:
                self._signals.metadataBatch.emit(batch)
                batch = []
        if batch:
            self._signals.metadataBatch.emit(batch)
        self._signals.finished.emit()


class CoverTask(QRunnable):
    """Odczytuje okładkę tylko dla aktualnie wyświetlanego utworu."""

    def __init__(self, path: str, signals: WorkerSignals) -> None:
        super().__init__()
        self._path = path
        self._signals = signals
        self.setAutoDelete(True)

    def run(self) -> None:
        try:
            data, mime = read_cover(self._path)
        except Exception:
            data, mime = None, "image/jpeg"
        self._signals.coverReady.emit(self._path, data or b"", mime)
