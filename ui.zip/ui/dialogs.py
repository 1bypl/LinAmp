"""Okna pomocy: skróty klawiszowe i informacje o programie."""

from __future__ import annotations

from PySide6.QtWidgets import QDialog, QDialogButtonBox, QMessageBox, QTextBrowser, QVBoxLayout

from .. import APP_NAME, __version__
from ..i18n import tr


def _shortcuts() -> list[tuple[str, str]]:
    return [
        ("Space", tr("Odtwórz / pauza")),
        ("X / C", tr("Odtwórz / pauza (klasycznie, jak w Winampie)")),
        ("Z / B", tr("Poprzedni / następny utwór")),
        ("V", tr("Stop")),
        ("← / →", tr("Przewiń o 5 sekund")),
        ("Shift + ← / →", tr("Przewiń o 30 sekund")),
        ("↑ / ↓", tr("Głośność ±5%")),
        ("M", tr("Wycisz / włącz dźwięk")),
        ("S", tr("Tryb losowy")),
        ("R", tr("Tryb powtarzania")),
        ("F", tr("Filtruj playlistę")),
        ("Enter", tr("Odtwórz zaznaczony utwór")),
        ("Delete", tr("Usuń zaznaczone z playlisty")),
        ("Ctrl + O", tr("Otwórz pliki")),
        ("Ctrl + Shift + O", tr("Dodaj cały folder")),
        ("Ctrl + L", tr("Wczytaj playlistę (M3U/PLS)")),
        ("Ctrl + S", tr("Zapisz playlistę (M3U/PLS)")),
        ("Ctrl + R", tr("Otwórz radio internetowe")),
        ("Ctrl + Shift + R", tr("Otwórz ulubione stacje radiowe")),
        ("Ctrl + E", tr("Korektor…")),
        ("F8", tr("Pokaż / ukryj playlistę")),
        ("F1", tr("Ta pomoc")),
        ("Ctrl + Q", tr("Zamknij program")),
    ]


def show_shortcuts(parent=None) -> None:
    dialog = QDialog(parent)
    dialog.setWindowTitle(tr("Skróty klawiszowe"))
    dialog.resize(540, 580)

    layout = QVBoxLayout(dialog)
    browser = QTextBrowser(dialog)

    rows = "".join(
        f"<tr>"
        f"<td style='padding:6px 10px; color:#1ed760; font-family:monospace; "
        f"white-space:nowrap;'>{key}</td>"
        f"<td style='padding:6px 10px; color:#e9edf2;'>{description}</td>"
        f"</tr>"
        for key, description in _shortcuts()
    )
    browser.setHtml(
        "<html><body style='background:#12151b;'>"
        f"<p style='color:#9aa3af; margin:4px 2px 10px 2px;'>"
        f"{tr('Większość skrótów działa także wtedy, gdy piszesz w polu filtra — wtedy traktujemy je jako tekst.')}</p>"
        f"<table cellspacing='0' cellpadding='0' width='100%'>{rows}</table>"
        "</body></html>"
    )
    layout.addWidget(browser)

    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok, dialog)
    buttons.accepted.connect(dialog.accept)
    layout.addWidget(buttons)
    dialog.exec()


def show_about(parent=None) -> None:
    QMessageBox.about(
        parent,
        tr("O programie {app}", app=APP_NAME),
        f"<h3>{APP_NAME} {__version__}</h3>"
        f"<p>{tr('Nowoczesny odtwarzacz muzyczny inspirowany Winampem — z darmowym radiem internetowym.')}</p>"
        f"<p>{tr('Napisany w Pythonie z użyciem PySide6 (Qt 6). Działa na Linuksie i Windowsie.')}</p>"
        f"<p style='color:#9aa3af;'>{tr('Formaty: MP3, FLAC, OGG/Opus, WAV, M4A/AAC, WMA i inne obsługiwane przez FFmpeg.')}</p>"
        f"<p style='color:#9aa3af;'>{tr('Radio: katalog SHOUTcast — ponad 300 kategorii, bez rejestracji.')}</p>"
        f"<p style='color:#9aa3af;'>{tr('Skróty klawiszowe: F1')}</p>",
    )
