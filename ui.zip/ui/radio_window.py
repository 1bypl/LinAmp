"""Okno radia internetowego: kategorie, wyszukiwanie, ulubione i nagrywanie."""

from __future__ import annotations

import os

from PySide6.QtCore import (
    QAbstractTableModel,
    QModelIndex,
    QSortFilterProxyModel,
    Qt,
    QThreadPool,
    QTimer,
    QUrl,
    Signal,
)
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from .. import APP_NAME
from ..config import Config
from ..i18n import station_count, tr
from ..playlist import Track, save_playlist
from ..radio import (
    FAVORITES_KEY,
    GenresTask,
    RadioSignals,
    RadioStation,
    StationsTask,
    StreamTask,
    TrackTask,
)
from ..recorder import RadioRecorder, default_recordings_dir
from ..theme import ACCENT, ACCENT_DARK, DIM, MUTED
from .icons import make_icon
from .widgets import FilterEdit

SORT_ROLE = Qt.ItemDataRole.UserRole + 20
STATION_ROLE = Qt.ItemDataRole.UserRole + 21


class StationModel(QAbstractTableModel):
    """Tabela stacji: nazwa, gatunek, jakość, słuchacze i aktualna piosenka."""

    HEADERS = ("Stacja", "Gatunek", "Jakość", "Słuchacze", "Teraz gra")

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._stations: list[RadioStation] = []
        self._playing_id = ""

    # --- podstawowe API modelu ---------------------------------------------
    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else len(self._stations)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:  # noqa: B008
        return 0 if parent.isValid() else len(self.HEADERS)

    def headerData(self, section: int, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return tr(self.HEADERS[section])
        return None

    def data(self, index: QModelIndex, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        row, col = index.row(), index.column()
        station = self._stations[row]

        if role == Qt.ItemDataRole.DisplayRole:
            if col == 0:
                return station.name
            if col == 1:
                return station.genre or "—"
            if col == 2:
                return station.quality
            if col == 3:
                return f"{station.listeners:,}".replace(",", " ")
            return station.current_track or "—"

        if role == SORT_ROLE:
            if col == 0:
                return station.name.casefold()
            if col == 1:
                return station.genre.casefold()
            if col == 2:
                return station.bitrate
            if col == 3:
                return station.listeners
            return station.current_track.casefold()

        if role == STATION_ROLE:
            return station

        if role == Qt.ItemDataRole.ToolTipRole:
            lines = [station.name]
            details = " • ".join(part for part in (station.genre, station.quality) if part)
            if details:
                lines.append(details)
            if station.current_track:
                lines.append(f"{tr('Teraz gra')}: {station.current_track}")
            if station.website:
                lines.append(station.website)
            return "\n".join(lines)

        if role == Qt.ItemDataRole.TextAlignmentRole:
            if col == 3:
                return Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
            return Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter

        if station.id == self._playing_id:
            if role == Qt.ItemDataRole.ForegroundRole:
                return QColor(ACCENT) if col in (0, 4) else QColor("#cfd6df")
            if role == Qt.ItemDataRole.BackgroundRole:
                return QColor(30, 215, 96, 20)
        elif role == Qt.ItemDataRole.ForegroundRole and col in (3, 4):
            return QColor(MUTED if col == 3 else DIM)
        return None

    # --- zarządzanie listą --------------------------------------------------
    def set_stations(self, stations: list[RadioStation]) -> None:
        self.beginResetModel()
        self._stations = list(stations)
        self.endResetModel()

    def station_at(self, row: int) -> RadioStation | None:
        if 0 <= row < len(self._stations):
            return self._stations[row]
        return None

    def set_playing(self, station_id: str) -> None:
        station_id = str(station_id or "")
        if station_id == self._playing_id:
            return
        self._playing_id = station_id
        if self._stations:
            self.dataChanged.emit(
                self.index(0, 0),
                self.index(len(self._stations) - 1, len(self.HEADERS) - 1),
            )

    def update_current_track(self, station_id: str, title: str) -> None:
        for row, station in enumerate(self._stations):
            if station.id == str(station_id):
                station.current_track = title
                self.dataChanged.emit(self.index(row, 4), self.index(row, 4))
                return


class StationProxy(QSortFilterProxyModel):
    """Filtrowanie po nazwie, gatunku i aktualnej piosence + sortowanie kolumn."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setDynamicSortFilter(True)
        self.setSortCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.setSortLocaleAware(True)
        self.setSortRole(SORT_ROLE)
        self._terms: list[str] = []

    def set_filter(self, text: str) -> None:
        self._terms = [term for term in text.lower().split() if term]
        self.invalidateFilter()

    def filterAcceptsRow(self, source_row: int, source_parent: QModelIndex) -> bool:
        if not self._terms:
            return True
        model: StationModel = self.sourceModel()  # type: ignore[assignment]
        station = model.station_at(source_row)
        if station is None:
            return False
        haystack = (
            f"{station.name} {station.genre} {station.current_track} {station.codec}"
        ).lower()
        return all(term in haystack for term in self._terms)


class RadioWindow(QDialog):
    """Niemodalne okno radia — można słuchać i dalej korzystać z playlisty."""

    stationActivated = Signal(object, str)   # RadioStation, adres strumienia
    currentTrackChanged = Signal(str, str)   # id stacji, tytuł piosenki

    def __init__(self, config: Config, engine=None, parent=None) -> None:
        super().__init__(parent)
        self._config = config
        self._engine = engine
        self._pool = QThreadPool.globalInstance()
        # Bez rodzica: sygnały żyją tak długo, jak zadania w tle.
        self._signals = RadioSignals()

        self._genres: list[str] = []
        self._genres_loaded = False
        self._genres_loading = False
        self._pending_favorites = False
        self._current_genre = FAVORITES_KEY
        self._stations: list[RadioStation] = []
        self._stream_cache: dict[str, str] = {}
        self._pending_station: RadioStation | None = None
        self._playing_station: RadioStation | None = None
        self._playing_url = ""
        self._favorites = self._load_favorites()

        self._recorder = RadioRecorder(self)
        self._recording_station_name = ""

        self._now_timer = QTimer(self)
        self._now_timer.setInterval(30000)
        self._now_timer.timeout.connect(self._refresh_now_playing)

        self.setObjectName("RadioWindow")
        self.setWindowTitle(tr("Radio internetowe — {app}", app=APP_NAME))
        self.setMinimumSize(760, 520)
        self.resize(980, 660)

        self._build_ui()
        self._connect_signals()
        self._populate_categories()
        self.categories.setCurrentRow(0)
        self._load_genres()

    # =====================================================================
    # Budowa interfejsu
    # =====================================================================
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 14)
        root.setSpacing(12)

        title = QLabel(tr("Radio internetowe"), self)
        title.setObjectName("SectionTitle")
        subtitle = QLabel(
            tr("Darmowe stacje z katalogu SHOUTcast — bez rejestracji i bez klucza API."),
            self,
        )
        subtitle.setStyleSheet(f"color: {MUTED};")
        root.addWidget(title)
        root.addWidget(subtitle)

        self.splitter = QSplitter(Qt.Orientation.Horizontal, self)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(12)

        # --- lewa strona: kategorie ----------------------------------------
        left = QWidget(self.splitter)
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)

        categories_title = QLabel(tr("Kategorie"), left)
        categories_title.setObjectName("SectionTitle")
        left_layout.addWidget(categories_title)

        self.categories = QListWidget(left)
        self.categories.setObjectName("RadioCategories")
        self.categories.setUniformItemSizes(True)
        self.categories.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        left_layout.addWidget(self.categories, 1)

        hint = QLabel(
            tr("Wybierz gatunek, aby zobaczyć stacje. Gwiazdka oznacza ulubione."),
            left,
        )
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {DIM}; font-size: 11px;")
        left_layout.addWidget(hint)

        self.splitter.addWidget(left)

        # --- prawa strona ---------------------------------------------------
        right = QWidget(self.splitter)
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)

        search_row = QHBoxLayout()
        search_row.setSpacing(8)
        self.search = FilterEdit(right)
        self.search.setPlaceholderText(tr("Szukaj stacji, gatunku lub piosenki…"))
        self.search.setClearButtonEnabled(True)
        self.search.setObjectName("RadioSearch")
        search_row.addWidget(self.search, 1)

        self.btn_refresh = QPushButton(tr("Odśwież"), right)
        self.btn_refresh.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_refresh.setToolTip(tr("Ponownie pobierz kategorię lub listę stacji"))
        search_row.addWidget(self.btn_refresh)
        right_layout.addLayout(search_row)

        self.model = StationModel(self)
        self.proxy = StationProxy(self)
        self.proxy.setSourceModel(self.model)

        self.table = QTableView(right)
        self.table.setModel(self.proxy)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setSortingEnabled(True)
        self.table.sortByColumn(3, Qt.SortOrder.DescendingOrder)
        self.table.setAlternatingRowColors(False)
        self.table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(34)

        header = self.table.horizontalHeader()
        header.setHighlightSections(False)
        header.setStretchLastSection(False)
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
        header.resizeSection(1, 130)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        header.resizeSection(2, 112)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        header.resizeSection(3, 92)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        header.setSortIndicator(3, Qt.SortOrder.DescendingOrder)
        right_layout.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        bottom.setSpacing(8)
        self.status = QLabel(tr("Wybierz kategorię z listy po lewej."), right)
        self.status.setObjectName("RadioStatus")
        self.status.setStyleSheet(f"color: {MUTED};")
        self.status.setWordWrap(True)
        bottom.addWidget(self.status, 1)

        self.btn_record = QPushButton(tr("Nagraj"), right)
        self.btn_record.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_record.setEnabled(False)
        self.btn_record.setToolTip(tr("Najpierw odtwórz stację, aby ją nagrać."))
        bottom.addWidget(self.btn_record)

        self.btn_fav = QPushButton(tr("☆ Dodaj do ulubionych"), right)
        self.btn_fav.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_fav.setEnabled(False)
        bottom.addWidget(self.btn_fav)

        self.btn_web = QPushButton(tr("Strona WWW"), right)
        self.btn_web.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_web.setEnabled(False)
        bottom.addWidget(self.btn_web)

        self.btn_play = QPushButton("  " + tr("Odtwórz"), right)
        self.btn_play.setObjectName("AccentButton")
        self.btn_play.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_play.setIcon(make_icon("play", ACCENT_DARK, 32))
        self.btn_play.setEnabled(False)
        bottom.addWidget(self.btn_play)

        right_layout.addLayout(bottom)
        self.splitter.addWidget(right)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setSizes([220, 740])
        root.addWidget(self.splitter, 1)

    def _connect_signals(self) -> None:
        self.categories.currentItemChanged.connect(self._on_category_changed)
        self.search.textChanged.connect(self.proxy.set_filter)
        self.search.escapePressed.connect(self._clear_search)
        self.table.doubleClicked.connect(lambda _index: self._activate_selected())
        self.table.selectionModel().selectionChanged.connect(
            lambda *_args: self._update_buttons()
        )
        self.btn_play.clicked.connect(self._activate_selected)
        self.btn_fav.clicked.connect(self._toggle_favorite)
        self.btn_web.clicked.connect(self._open_website)
        self.btn_refresh.clicked.connect(self._refresh_current)
        self.btn_record.clicked.connect(self._toggle_recording)

        self._signals.genresReady.connect(self._on_genres_ready)
        self._signals.genresFailed.connect(self._on_genres_failed)
        self._signals.stationsReady.connect(self._on_stations_ready)
        self._signals.stationsFailed.connect(self._on_stations_failed)
        self._signals.streamReady.connect(self._on_stream_ready)
        self._signals.streamFailed.connect(self._on_stream_failed)
        self._signals.trackReady.connect(self._on_track_ready)

        self._recorder.finished.connect(self._on_recording_finished)
        self._recorder.error.connect(self._on_recording_error)
        self._recorder.elapsedChanged.connect(self._on_recording_elapsed)

    # =====================================================================
    # Kategorie
    # =====================================================================
    def _populate_categories(self) -> None:
        key = self._current_genre
        self.categories.blockSignals(True)
        self.categories.clear()

        favorites = QListWidgetItem(tr("★ Ulubione"))
        favorites.setData(Qt.ItemDataRole.UserRole, FAVORITES_KEY)
        self.categories.addItem(favorites)

        if self._genres_loaded:
            for genre in self._genres:
                item = QListWidgetItem(genre)
                item.setData(Qt.ItemDataRole.UserRole, genre)
                self.categories.addItem(item)
        else:
            loading = QListWidgetItem(
                tr("Ładowanie kategorii…") if self._genres_loading else tr("Brak kategorii")
            )
            loading.setFlags(Qt.ItemFlag.NoItemFlags)
            loading.setForeground(QColor(DIM))
            self.categories.addItem(loading)

        target = 0
        for row in range(self.categories.count()):
            if self.categories.item(row).data(Qt.ItemDataRole.UserRole) == key:
                target = row
                break
        if self._pending_favorites:
            target = 0
        self.categories.setCurrentRow(target)
        self.categories.blockSignals(False)

    def _load_genres(self) -> None:
        if self._genres_loading:
            return
        self._genres_loading = True
        if not self._genres_loaded:
            self.status.setText(tr("Pobieranie listy kategorii…"))
        self._pool.start(GenresTask(self._signals))

    def _on_genres_ready(self, genres: list) -> None:
        self._genres_loading = False
        self._genres_loaded = True
        self._genres = [str(name) for name in genres if str(name).strip()]
        self._populate_categories()

        current = self.categories.currentItem()
        key = current.data(Qt.ItemDataRole.UserRole) if current is not None else None
        if key in (None, FAVORITES_KEY):
            self._show_favorites()
            if not self._favorites:
                self.status.setText(
                    tr("Gotowe — {count} kategorii. Wybierz gatunek z listy po lewej.",
                       count=len(self._genres))
                )
        else:
            self._load_stations(str(key))

    def _on_genres_failed(self, message: str) -> None:
        self._genres_loading = False
        self._genres_loaded = False
        self._populate_categories()
        self.status.setText(
            tr("Nie udało się pobrać kategorii: {message} Sprawdź internet i kliknij „Odśwież”.",
               message=message)
        )

    def _on_category_changed(self, current: QListWidgetItem, _previous) -> None:
        if current is None:
            return
        key = current.data(Qt.ItemDataRole.UserRole)
        if key is None:
            return
        if key == FAVORITES_KEY:
            self._pending_favorites = False
            self._show_favorites()
        else:
            self._load_stations(str(key))

    # =====================================================================
    # Lista stacji
    # =====================================================================
    def _load_stations(self, genre: str) -> None:
        self._current_genre = genre
        self._stations = []
        self.model.set_stations([])
        self._update_buttons()
        self.status.setText(tr("Pobieranie stacji w kategorii „{genre}”…", genre=genre))
        self.btn_refresh.setEnabled(False)
        self._pool.start(StationsTask(genre, self._signals))

    def _on_stations_ready(self, genre: str, stations: list) -> None:
        if genre != self._current_genre:
            return
        self.btn_refresh.setEnabled(True)
        self._stations = [s for s in stations if isinstance(s, RadioStation)]
        self.model.set_stations(self._stations)
        self._sync_playing_row()
        if self._stations:
            self.table.selectRow(0)
            self.status.setText(
                tr("{count} stacji w kategorii „{genre}”. Kliknij dwukrotnie, aby odtworzyć.",
                   count=len(self._stations), genre=genre)
            )
        else:
            self.status.setText(tr("Brak stacji w kategorii „{genre}”.", genre=genre))

    def _on_stations_failed(self, genre: str, message: str) -> None:
        if genre != self._current_genre:
            return
        self.btn_refresh.setEnabled(True)
        self.status.setText(tr("Nie udało się pobrać stacji: {message}", message=message))

    def _show_favorites(self) -> None:
        self._current_genre = FAVORITES_KEY
        self._stations = [RadioStation.from_dict(item) for item in self._favorites]
        self.model.set_stations(self._stations)
        self._sync_playing_row()
        if self._stations:
            self.table.selectRow(0)
        self._update_buttons()
        if self._stations:
            self.status.setText(
                tr("{count} ulubionych stacji. Kliknij dwukrotnie, aby odtworzyć.",
                   count=len(self._stations))
            )
        else:
            self.status.setText(
                tr("Nie masz jeszcze ulubionych stacji. Wybierz gatunek i dodaj stację gwiazdką.")
            )

    def _refresh_current(self) -> None:
        if not self._genres_loaded:
            self._load_genres()
        elif self._current_genre == FAVORITES_KEY:
            self._show_favorites()
        else:
            self._load_stations(self._current_genre)

    def _clear_search(self) -> None:
        self.search.clear()
        self.table.setFocus()

    # =====================================================================
    # Wybór i odtwarzanie
    # =====================================================================
    def _selected_station(self) -> RadioStation | None:
        index = self.table.currentIndex()
        if not index.isValid():
            return None
        source = self.proxy.mapToSource(index)
        return self.model.station_at(source.row())

    def _update_buttons(self) -> None:
        station = self._selected_station()
        self.btn_play.setEnabled(station is not None)
        self.btn_web.setEnabled(bool(station and station.website))
        self.btn_fav.setEnabled(station is not None)
        can_record = self._playing_station is not None and self._engine is not None
        self.btn_record.setEnabled(can_record or self._recorder.is_recording)
        if self._recorder.is_recording:
            self.btn_record.setText(tr("Zatrzymaj nagrywanie"))
            self.btn_record.setToolTip(tr("Zatrzymaj nagrywanie"))
        else:
            self.btn_record.setText(tr("Nagraj"))
            self.btn_record.setToolTip(
                tr("Najpierw odtwórz stację, aby ją nagrać.") if not can_record else tr("Nagraj")
            )
        if station is None:
            self.btn_fav.setText(tr("☆ Dodaj do ulubionych"))
            return
        if self._is_favorite(station):
            self.btn_fav.setText(tr("★ Usuń z ulubionych"))
            self.btn_fav.setToolTip(tr("Ta stacja jest już w ulubionych"))
        else:
            self.btn_fav.setText(tr("☆ Dodaj do ulubionych"))
            self.btn_fav.setToolTip(tr("Dodaj stację do ulubionych"))

    def _activate_selected(self) -> None:
        station = self._selected_station()
        if station is None:
            return
        self.request_station(station)

    def request_station(self, station: RadioStation) -> None:
        cached = self._stream_cache.get(station.id)
        if cached:
            self.stationActivated.emit(station, cached)
            return
        self._pending_station = station
        self.btn_play.setEnabled(False)
        self.status.setText(tr("Łączenie ze stacją „{name}”…", name=station.name))
        self._pool.start(StreamTask(station.id, self._signals))

    def _on_stream_ready(self, station_id: str, url: str) -> None:
        self._stream_cache[station_id] = url
        station = self._pending_station
        if station is None or station.id != str(station_id):
            return
        self._pending_station = None
        self.btn_play.setEnabled(True)
        self.status.setText(tr("Odtwarzanie: {name}", name=station.name))
        self.stationActivated.emit(station, url)

    def _on_stream_failed(self, station_id: str, message: str) -> None:
        station = self._pending_station
        if station is None or station.id != str(station_id):
            return
        self._pending_station = None
        self.btn_play.setEnabled(True)
        self.status.setText(tr("Nie można połączyć ze stacją: {message}", message=message))

    def set_now_playing(self, station: RadioStation | None, url: str = "") -> None:
        """Wywoływane przez główne okno po rozpoczęciu/zakończeniu radia."""
        if self._recorder.is_recording and (
            station is None or station.id != getattr(self._playing_station, "id", "")
        ):
            self._recorder.stop()
        self._playing_station = station
        self._playing_url = url or ""
        self.model.set_playing(station.id if station is not None else "")
        self._update_buttons()
        if station is None:
            self._now_timer.stop()
            return
        self._sync_playing_row()
        self._now_timer.start()
        self._refresh_now_playing()

    def _sync_playing_row(self) -> None:
        if self._playing_station is not None:
            self.model.set_playing(self._playing_station.id)

    def _refresh_now_playing(self) -> None:
        if self._playing_station is None:
            return
        self._pool.start(TrackTask(self._playing_station.id, self._signals))

    def _on_track_ready(self, station_id: str, title: str) -> None:
        station = self._playing_station
        if station is None or station.id != str(station_id) or not title:
            return
        station.current_track = title
        self.model.update_current_track(station.id, title)

        changed = False
        for item in self._favorites:
            if str(item.get("id")) == station.id:
                item["current_track"] = title
                changed = True
                break
        if changed:
            self._save_favorites()

        self.currentTrackChanged.emit(station.id, title)

    def show_favorites(self) -> None:
        self._pending_favorites = True
        for row in range(self.categories.count()):
            item = self.categories.item(row)
            if item.data(Qt.ItemDataRole.UserRole) == FAVORITES_KEY:
                self.categories.setCurrentRow(row)
                break
        if self._current_genre == FAVORITES_KEY:
            self._show_favorites()

    # =====================================================================
    # Nagrywanie
    # =====================================================================
    def _toggle_recording(self) -> None:
        if self._recorder.is_recording:
            self.status.setText(tr("Przetwarzanie nagrania…"))
            self._recorder.stop()
            self._update_buttons()
            return
        if self._playing_station is None or self._engine is None:
            self.status.setText(tr("Najpierw odtwórz stację, aby ją nagrać."))
            return
        self._recording_station_name = self._playing_station.name
        if self._recorder.start(self._recording_station_name, self._engine, self._config):
            self.status.setText(tr("Nagrywanie: {name}", name=self._recording_station_name))
        self._update_buttons()

    def _on_recording_elapsed(self, seconds: int) -> None:
        if self._recorder.is_recording:
            mins, secs = divmod(int(seconds), 60)
            self.status.setText(
                tr("Nagrywanie… {time}", time=f"{mins}:{secs:02d}")
                + f" — {self._recording_station_name}"
            )

    def _on_recording_finished(self, path: str, fmt: str) -> None:
        if fmt == "mp3":
            self.status.setText(tr("Nagranie zapisano jako MP3: {path}", path=path))
        elif fmt == "m4a":
            self.status.setText(tr("Nagranie zapisano jako M4A: {path}", path=path))
        else:
            self.status.setText(tr("Nagranie zapisano jako WAV: {path}", path=path))
        self._update_buttons()

    def _on_recording_error(self, message: str) -> None:
        self.status.setText(tr("Nie udało się zapisać nagrania: {error}", error=message))
        self._update_buttons()

    # =====================================================================
    # Ulubione i strona WWW
    # =====================================================================
    def _load_favorites(self) -> list[dict]:
        raw = self._config.get("radio_favorites", [])
        result: list[dict] = []
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict) and item.get("id") and item.get("name"):
                    result.append(dict(item))
        return result

    def _save_favorites(self) -> None:
        self._config.set("radio_favorites", self._favorites)
        self._config.save()

    def _is_favorite(self, station: RadioStation) -> bool:
        return any(str(item.get("id")) == station.id for item in self._favorites)

    def _toggle_favorite(self) -> None:
        station = self._selected_station()
        if station is None:
            return

        if self._is_favorite(station):
            self._favorites = [
                item for item in self._favorites
                if str(item.get("id")) != station.id
            ]
            self.status.setText(tr("Usunięto z ulubionych: {name}", name=station.name))
        else:
            self._favorites.append(station.to_dict())
            self.status.setText(tr("Dodano do ulubionych: {name}", name=station.name))

        self._save_favorites()
        self._update_buttons()
        if self._current_genre == FAVORITES_KEY:
            self._show_favorites()

    def _open_website(self) -> None:
        station = self._selected_station()
        if station is not None and station.website:
            QDesktopServices.openUrl(QUrl(station.website))

    # =====================================================================
    # Zamknięcie
    # =====================================================================
    def closeEvent(self, event) -> None:  # noqa: N802
        # Nagrywanie zatrzymujemy, żeby plik został poprawnie domknięty.
        if self._recorder.is_recording:
            self._recorder.stop()
        self._now_timer.stop()
        super().closeEvent(event)
