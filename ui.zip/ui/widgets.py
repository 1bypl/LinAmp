"""Elementy interfejsu: przyciski z ikonami, suwaki, okładka, etykiety czasu."""

from __future__ import annotations

from PySide6.QtCore import QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import QLabel, QLineEdit, QPushButton, QSlider, QWidget

from ..theme import (
    ACCENT,
    ACCENT_DARK,
    ACCENT_HOVER,
    ACCENT_PRESSED,
    BORDER,
    DIM,
    MUTED,
    SURFACE_2,
    SURFACE_3,
    TEXT,
)
from .icons import draw_icon


class TimeLabel(QLabel):
    """Etykieta z czasem — czcionka o stałej szerokości, żeby cyfry nie skakały."""

    def __init__(self, text: str = "0:00", parent=None) -> None:
        super().__init__(text, parent)
        font = QFont()
        font.setFamilies(["DejaVu Sans Mono", "Consolas", "Courier New", "Monospace"])
        font.setStyleHint(QFont.StyleHint.Monospace)
        font.setPointSizeF(10.0)
        font.setBold(True)
        self.setFont(font)
        self.setStyleSheet(f"color: {MUTED}; background: transparent;")
        self.setMinimumWidth(46)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)

    def set_highlight(self, active: bool) -> None:
        """Podświetla czas na zielono (np. napis „NA ŻYWO” w radiu)."""
        color = ACCENT if active else MUTED
        self.setStyleSheet(f"color: {color}; background: transparent;")


class IconButton(QPushButton):
    """Kwadratowy przycisk z wektorową ikoną (bez ramki, z efektem hover)."""

    def __init__(
        self,
        icon_name: str,
        parent=None,
        size: int = 34,
        icon_size: int = 17,
        tooltip: str = "",
        checkable: bool = False,
        dim: bool = False,
    ) -> None:
        super().__init__(parent)
        self._icon_name = icon_name
        self._icon_size = icon_size
        self._dim = dim
        self.setFixedSize(size, size)
        self.setCheckable(checkable)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        if tooltip:
            self.setToolTip(tooltip)

    def set_icon_name(self, name: str) -> None:
        if name != self._icon_name:
            self._icon_name = name
            self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        hovered = self.underMouse() and self.isEnabled()

        if self.isChecked():
            background = QColor(30, 215, 96, 38)
            color = QColor(ACCENT)
        elif self.isDown():
            background = QColor(255, 255, 255, 22)
            color = QColor(TEXT)
        elif hovered:
            background = QColor(255, 255, 255, 12)
            color = QColor(TEXT)
        else:
            background = QColor(0, 0, 0, 0)
            color = QColor(MUTED if self._dim else TEXT)

        if not self.isEnabled():
            color = QColor(DIM)

        if background.alpha():
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(background)
            painter.drawRoundedRect(rect, 9, 9)

        icon_rect = QRectF(0, 0, self._icon_size, self._icon_size)
        icon_rect.moveCenter(rect.center())
        draw_icon(painter, self._icon_name, icon_rect, color)


class PlayButton(QPushButton):
    """Duży, okrągły przycisk odtwarzania/pauzy."""

    def __init__(self, parent=None, size: int = 56, tooltip: str = "") -> None:
        super().__init__(parent)
        self.setFixedSize(size, size)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._playing = False
        if tooltip:
            self.setToolTip(tooltip)

    def set_playing(self, playing: bool) -> None:
        playing = bool(playing)
        if playing != self._playing:
            self._playing = playing
            self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        rect = QRectF(self.rect()).adjusted(2.0, 2.0, -2.0, -2.0)
        if self.isDown():
            color = QColor(ACCENT_PRESSED)
        elif self.underMouse():
            color = QColor(ACCENT_HOVER)
        else:
            color = QColor(ACCENT)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(color)
        painter.drawEllipse(rect)

        icon_rect = QRectF(0, 0, 24, 24)
        icon_rect.moveCenter(rect.center())
        draw_icon(painter, "pause" if self._playing else "play", icon_rect, QColor(ACCENT_DARK))


class _SliderBase(QSlider):
    """Wspólna baza dla suwaków: cienki tor, wypełnienie akcentem, okrągły uchwyt."""

    def __init__(self, parent=None, track_height: float = 4.0, handle: float = 5.0) -> None:
        super().__init__(Qt.Orientation.Horizontal, parent)
        self._track_height = track_height
        self._handle_radius = handle
        self._hover = False
        self._dragging = False
        self.setFixedHeight(22)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

    # --- reakcje na mysz ----------------------------------------------------
    def enterEvent(self, event) -> None:  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._hover = False
        self.update()

    def _value_from_x(self, x: float) -> int:
        margin = 8.0
        width = max(1.0, self.width() - 2 * margin)
        ratio = min(1.0, max(0.0, (x - margin) / width))
        span = self.maximum() - self.minimum()
        return int(round(self.minimum() + ratio * span))

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton and self.maximum() > self.minimum():
            self._dragging = True
            self.setValue(self._value_from_x(event.position().x()))
            self._on_drag()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self._dragging:
            self.setValue(self._value_from_x(event.position().x()))
            self._on_drag()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if self._dragging:
            self._dragging = False
            self.setValue(self._value_from_x(event.position().x()))
            self._on_drag()
            self.update()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def _on_drag(self) -> None:
        """Nadpisywane w klasach potomnych."""

    @property
    def dragging(self) -> bool:
        """Czy użytkownik właśnie przeciąga uchwyt suwaka."""
        return self._dragging

    # --- rysowanie ----------------------------------------------------------
    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        margin = 8.0
        track_height = self._track_height
        top = (self.height() - track_height) / 2.0
        track = QRectF(margin, top, max(1.0, self.width() - 2 * margin), track_height)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(SURFACE_3))
        painter.drawRoundedRect(track, track_height / 2, track_height / 2)

        span = self.maximum() - self.minimum()
        ratio = (self.value() - self.minimum()) / span if span > 0 else 0.0

        if ratio > 0:
            filled = QRectF(track.x(), track.y(), track.width() * ratio, track.height())
            gradient = QLinearGradient(filled.topLeft(), filled.topRight())
            gradient.setColorAt(0.0, QColor(ACCENT))
            gradient.setColorAt(1.0, QColor(ACCENT_HOVER))
            painter.setBrush(gradient)
            painter.drawRoundedRect(filled, track_height / 2, track_height / 2)

        center_x = track.x() + track.width() * ratio
        center_y = track.center().y()
        radius = self._handle_radius + (1.5 if (self._hover or self._dragging) else 0.0)

        if self.isEnabled():
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(30, 215, 96, 60))
            painter.drawEllipse(QRectF(center_x - radius - 3, center_y - radius - 3,
                                       (radius + 3) * 2, (radius + 3) * 2))
            painter.setBrush(QColor("#f4f7fa"))
            painter.drawEllipse(QRectF(center_x - radius, center_y - radius,
                                       radius * 2, radius * 2))


class SeekSlider(_SliderBase):
    """Suwak postępu — kliknięcie od razu przewija utwór."""

    seekRequested = Signal(int)

    def __init__(self, parent=None) -> None:
        super().__init__(parent, track_height=4.0, handle=5.0)
        self.setRange(0, 0)
        self.setSingleStep(1000)
        self.setPageStep(5000)

    def _on_drag(self) -> None:
        self.seekRequested.emit(self.value())


class VolumeSlider(_SliderBase):
    """Suwak głośności (0–100)."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent, track_height=3.5, handle=4.5)
        self.setRange(0, 100)
        self.setValue(80)
        self.setFixedWidth(120)


class CoverWidget(QWidget):
    """Kwadratowy obrazek okładki z zaokrąglonymi rogami."""

    def __init__(self, size: int = 74, parent=None) -> None:
        super().__init__(parent)
        self.setFixedSize(size, size)
        self._pixmap: QPixmap | None = None
        self._placeholder = "note"

    def set_pixmap(self, pixmap: QPixmap | None) -> None:
        self._pixmap = pixmap
        self.update()

    def set_placeholder(self, icon_name: str) -> None:
        """Zmienia ikonę widoczną, gdy utwór nie ma okładki (np. „radio”)."""
        if icon_name != self._placeholder:
            self._placeholder = icon_name
            self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)

        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath()
        path.addRoundedRect(rect, 11, 11)
        painter.setClipPath(path)

        if self._pixmap is not None and not self._pixmap.isNull():
            target = self.rect()
            scaled = self._pixmap.scaled(
                target.size(),
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation,
            )
            source = QRectF(
                max(0.0, (scaled.width() - target.width()) / 2.0),
                max(0.0, (scaled.height() - target.height()) / 2.0),
                target.width(),
                target.height(),
            )
            painter.drawPixmap(QRectF(target), scaled, source)
        else:
            painter.fillPath(path, QColor(SURFACE_2))
            center = rect.center()
            icon_rect = QRectF(center.x() - 15, center.y() - 15, 30, 30)
            draw_icon(painter, self._placeholder, icon_rect, QColor(DIM))

        painter.setClipping(False)
        painter.setPen(QPen(QColor(BORDER), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)


class FilterEdit(QLineEdit):
    """Pole filtrowania — Esc czyści filtr i wraca do listy."""

    escapePressed = Signal()

    def keyPressEvent(self, event) -> None:  # noqa: N802
        if event.key() == Qt.Key.Key_Escape:
            self.escapePressed.emit()
            event.accept()
            return
        super().keyPressEvent(event)
