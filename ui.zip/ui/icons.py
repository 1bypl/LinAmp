"""Wektorowe ikony rysowane przez QPainter.

Dzięki temu nie potrzebujemy plików PNG ani zewnętrznych zestawów ikon,
a wszystkie ikony są ostre na ekranach o dowolnej rozdzielczości.
"""

from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (
    QColor,
    QFont,
    QIcon,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)

from ..theme import ACCENT_DARK, TEXT


def _fill(p: QPainter, path: QPainterPath, color: QColor) -> None:
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(color)
    p.fillPath(path, color)


def _stroke(p: QPainter, color: QColor, width: float = 2.0) -> None:
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.setPen(
        QPen(
            color,
            width,
            Qt.PenStyle.SolidLine,
            Qt.PenCapStyle.RoundCap,
            Qt.PenJoinStyle.RoundJoin,
        )
    )


def draw_icon(p: QPainter, name: str, rect: QRectF, color: QColor) -> None:
    """Rysuje ikonę `name` w prostokącie `rect` (skala 24x24)."""
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

    side = max(1.0, min(rect.width(), rect.height()))
    x = rect.x() + (rect.width() - side) / 2.0
    y = rect.y() + (rect.height() - side) / 2.0
    p.translate(x, y)
    p.scale(side / 24.0, side / 24.0)

    if name == "play":
        path = QPainterPath()
        path.moveTo(8.5, 5.2)
        path.lineTo(19.2, 12.0)
        path.lineTo(8.5, 18.8)
        path.closeSubpath()
        _fill(p, path, color)

    elif name == "pause":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(color)
        p.drawRoundedRect(QRectF(7.0, 5.0, 3.7, 14.0), 1.5, 1.5)
        p.drawRoundedRect(QRectF(13.3, 5.0, 3.7, 14.0), 1.5, 1.5)

    elif name == "stop":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(color)
        p.drawRoundedRect(QRectF(6.4, 6.4, 11.2, 11.2), 2.2, 2.2)

    elif name == "prev":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(color)
        p.drawRoundedRect(QRectF(6.0, 5.0, 2.5, 14.0), 1.0, 1.0)
        path = QPainterPath()
        path.moveTo(18.8, 5.2)
        path.lineTo(9.2, 12.0)
        path.lineTo(18.8, 18.8)
        path.closeSubpath()
        p.fillPath(path, color)

    elif name == "next":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(color)
        p.drawRoundedRect(QRectF(15.5, 5.0, 2.5, 14.0), 1.0, 1.0)
        path = QPainterPath()
        path.moveTo(5.2, 5.2)
        path.lineTo(14.8, 12.0)
        path.lineTo(5.2, 18.8)
        path.closeSubpath()
        p.fillPath(path, color)

    elif name == "shuffle":
        _stroke(p, color, 1.9)
        upper = QPainterPath()
        upper.moveTo(3.2, 7.0)
        upper.cubicTo(7.5, 7.0, 10.0, 17.0, 16.4, 17.0)
        upper.moveTo(13.4, 14.6)
        upper.lineTo(16.8, 17.0)
        upper.lineTo(13.4, 19.4)
        p.drawPath(upper)

        lower = QPainterPath()
        lower.moveTo(3.2, 17.0)
        lower.cubicTo(7.5, 17.0, 10.0, 7.0, 16.4, 7.0)
        lower.moveTo(13.4, 4.6)
        lower.lineTo(16.8, 7.0)
        lower.lineTo(13.4, 9.4)
        p.drawPath(lower)

    elif name in ("repeat", "repeat_one"):
        _stroke(p, color, 1.8)
        path = QPainterPath()
        path.moveTo(6.6, 9.4)
        path.lineTo(6.6, 7.6)
        path.quadTo(6.6, 6.0, 8.2, 6.0)
        path.lineTo(17.0, 6.0)
        path.moveTo(14.4, 3.6)
        path.lineTo(17.4, 6.0)
        path.lineTo(14.4, 8.4)

        path.moveTo(17.4, 14.6)
        path.lineTo(17.4, 16.4)
        path.quadTo(17.4, 18.0, 15.8, 18.0)
        path.lineTo(7.0, 18.0)
        path.moveTo(9.6, 15.6)
        path.lineTo(6.6, 18.0)
        path.lineTo(9.6, 20.4)
        p.drawPath(path)

        if name == "repeat_one":
            font = QFont()
            font.setBold(True)
            font.setPixelSize(8)
            p.setFont(font)
            p.setPen(color)
            p.drawText(QRectF(9.0, 8.6, 6.0, 7.0), Qt.AlignmentFlag.AlignCenter, "1")

    elif name in ("volume", "mute"):
        speaker = QPainterPath()
        speaker.moveTo(3.4, 9.2)
        speaker.lineTo(7.2, 9.2)
        speaker.lineTo(10.8, 5.6)
        speaker.lineTo(10.8, 18.4)
        speaker.lineTo(7.2, 14.8)
        speaker.lineTo(3.4, 14.8)
        speaker.closeSubpath()
        _fill(p, speaker, color)

        if name == "volume":
            _stroke(p, color, 1.7)
            for arc_rect, start, sweep in (
                (QRectF(10.0, 7.2, 8.4, 9.6), -55.0, 110.0),
                (QRectF(9.4, 9.4, 5.2, 5.2), -50.0, 100.0),
            ):
                arc = QPainterPath()
                arc.arcMoveTo(arc_rect, start)
                arc.arcTo(arc_rect, start, sweep)
                p.drawPath(arc)
        else:
            _stroke(p, color, 1.9)
            p.drawLine(QPointF(14.6, 9.2), QPointF(20.4, 15.0))
            p.drawLine(QPointF(20.4, 9.2), QPointF(14.6, 15.0))

    elif name == "plus":
        _stroke(p, color, 2.0)
        p.drawLine(QPointF(12.0, 5.5), QPointF(12.0, 18.5))
        p.drawLine(QPointF(5.5, 12.0), QPointF(18.5, 12.0))

    elif name == "folder":
        _stroke(p, color, 1.8)
        path = QPainterPath()
        path.moveTo(3.5, 8.2)
        path.lineTo(9.2, 8.2)
        path.lineTo(11.2, 10.2)
        path.lineTo(20.0, 10.2)
        path.quadTo(21.0, 10.2, 21.0, 11.2)
        path.lineTo(21.0, 17.3)
        path.quadTo(21.0, 18.5, 19.8, 18.5)
        path.lineTo(4.7, 18.5)
        path.quadTo(3.5, 18.5, 3.5, 17.3)
        path.closeSubpath()
        p.drawPath(path)

    elif name == "file":
        _stroke(p, color, 1.8)
        path = QPainterPath()
        path.moveTo(6.0, 3.8)
        path.lineTo(14.0, 3.8)
        path.lineTo(18.8, 8.6)
        path.lineTo(18.8, 20.2)
        path.lineTo(6.0, 20.2)
        path.closeSubpath()
        path.moveTo(14.0, 3.8)
        path.lineTo(14.0, 8.6)
        path.lineTo(18.8, 8.6)
        p.drawPath(path)

    elif name == "save":
        _stroke(p, color, 1.7)
        outer = QPainterPath()
        outer.addRoundedRect(QRectF(4.4, 4.4, 15.2, 15.2), 2.0, 2.0)
        p.drawPath(outer)
        p.drawRect(QRectF(8.2, 4.8, 7.0, 4.2))
        p.drawRect(QRectF(7.6, 12.8, 8.8, 6.8))

    elif name == "trash":
        _stroke(p, color, 1.8)
        p.drawLine(QPointF(4.4, 7.0), QPointF(19.6, 7.0))
        path = QPainterPath()
        path.moveTo(6.8, 7.0)
        path.lineTo(7.7, 19.2)
        path.lineTo(16.3, 19.2)
        path.lineTo(17.2, 7.0)
        p.drawPath(path)
        handle = QPainterPath()
        handle.moveTo(9.4, 7.0)
        handle.lineTo(9.4, 5.0)
        handle.lineTo(14.6, 5.0)
        handle.lineTo(14.6, 7.0)
        p.drawPath(handle)
        p.drawLine(QPointF(10.4, 10.2), QPointF(10.4, 16.0))
        p.drawLine(QPointF(13.6, 10.2), QPointF(13.6, 16.0))

    elif name == "note":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(color)
        p.drawEllipse(QRectF(6.6, 15.2, 5.2, 3.8))
        p.drawRoundedRect(QRectF(10.9, 5.6, 1.9, 11.0), 0.9, 0.9)
        flag = QPainterPath()
        flag.moveTo(12.8, 5.6)
        flag.cubicTo(17.4, 7.0, 17.8, 10.2, 13.6, 11.6)
        flag.lineTo(13.6, 9.2)
        flag.cubicTo(15.8, 8.4, 15.6, 7.2, 12.8, 7.0)
        flag.closeSubpath()
        p.fillPath(flag, color)

    elif name == "radio":
        _stroke(p, color, 1.8)
        body = QPainterPath()
        body.addRoundedRect(QRectF(3.2, 7.6, 17.6, 11.9), 2.2, 2.2)
        p.drawPath(body)

        # Antena
        p.drawLine(QPointF(8.2, 7.6), QPointF(15.2, 3.2))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(color)
        p.drawEllipse(QRectF(14.6, 2.2, 2.4, 2.4))

        # Głośnik
        _stroke(p, color, 1.6)
        p.drawEllipse(QRectF(5.8, 10.2, 5.4, 5.4))
        p.drawEllipse(QRectF(7.6, 12.0, 1.8, 1.8))

        # Linie „strojenia”
        p.drawLine(QPointF(13.2, 10.8), QPointF(18.2, 10.8))
        p.drawLine(QPointF(13.2, 13.6), QPointF(18.2, 13.6))
        p.drawLine(QPointF(13.2, 16.4), QPointF(16.4, 16.4))

    elif name == "close":
        _stroke(p, color, 2.0)
        p.drawLine(QPointF(6.5, 6.5), QPointF(17.5, 17.5))
        p.drawLine(QPointF(17.5, 6.5), QPointF(6.5, 17.5))

    p.restore()


def make_icon(name: str, color: str = TEXT, size: int = 64) -> QIcon:
    """Tworzy QIcon z wektorowej ikony (do menu i zasobnika)."""
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    padding = size * 0.12
    draw_icon(
        painter,
        name,
        QRectF(padding, padding, size - 2 * padding, size - 2 * padding),
        QColor(color),
    )
    painter.end()
    return QIcon(pixmap)


def make_app_icon(size: int = 256) -> QIcon:
    """Ikona aplikacji: zielone zaokrąglone tło z ciemnym trójkątem play."""
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

    rect = QRectF(0, 0, size, size).adjusted(size * 0.03, size * 0.03, -size * 0.03, -size * 0.03)
    gradient = QLinearGradient(0, 0, size, size)
    gradient.setColorAt(0.0, QColor("#2ef07a"))
    gradient.setColorAt(1.0, QColor("#12a44c"))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(gradient)
    painter.drawRoundedRect(rect, size * 0.24, size * 0.24)

    draw_icon(
        painter,
        "play",
        QRectF(size * 0.30, size * 0.30, size * 0.42, size * 0.42),
        QColor(ACCENT_DARK),
    )
    painter.end()

    icon = QIcon()
    icon.addPixmap(pixmap)
    return icon
