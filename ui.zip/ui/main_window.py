"""Główne okno odtwarzacza LinAmp."""

from __future__ import annotations

import base64
import os
import sys
from collections import OrderedDict
from pathlib import Path

from PySide6.QtCore import QByteArray, QProcess, Qt, QThreadPool, QTimer, QUrl
from PySide6.QtGui import (
    QAction,
    QActionGroup,
    QDesktopServices,
    QKeySequence,
    QPixmap,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QSplitter,
    QStatusBar,
    QTableView,
    QVBoxLayout,
    QWidget,
    QSystemTrayIcon,
)

from .. import APP_NAME
from ..audio import AudioEngine
from ..config import Config
from ..equalizer import Equalizer
from ..i18n import LANGUAGES, language, set_language, tr, track_count
from ..metadata import is_audio_file, scan_folder
from ..radio import RadioStation
from ..playlist import (
    PlaylistModel,
    PlaylistProxy,
    Track,
    format_duration,
    load_playlist,
    save_playlist,
)
from ..theme import MUTED, TEXT
from .controller import PlaybackController
from .dialogs import show_about, show_shortcuts
from .equalizer_window import EqualizerWindow
from .icons import make_app_icon, make_icon
from .radio_window import RadioWindow
from .spectrum import SpectrumWidget
from .widgets import (
    CoverWidget,
    FilterEdit,
    IconButton,
    PlayButton,
    SeekSlider,
    TimeLabel,
    VolumeSlider,
)
from .workers import CoverTask, MetadataTask, WorkerSignals

AUDIO_FILTER = tr(
    "Pliki audio (*.mp3 *.flac *.ogg *.oga *.opus *.wav *.m4a *.aac *.wma "
    "*.aiff *.aif *.alac *.wv *.ape *.mpc);;Wszystkie pliki (*)"
)
PLAYLIST_FILTER = tr(
    "Playlisty (*.m3u *.m3u8 *.pls);;M3U (*.m3u *.m3u8);;"
    "PLS (*.pls);;Wszystkie pliki (*)"
)


class MainWindow(QMainWindow):
    def __init__(self, config: Config, parent=None) -> None:
        super().__init__(parent)
        self.config = config

        self.model = PlaylistModel(self)
        self.proxy = PlaylistProxy(self)
        self.proxy.setSourceModel(self.model)

        self.engine = AudioEngine(self)
        self.controller = PlaybackController(self.model, self.engine, config, self)
        self.equalizer = Equalizer(self.engine, self)

        self._pool = QThreadPool.globalInstance()
        self._signals = WorkerSignals(self)
        self._cover_cache: OrderedDict[str, QPixmap | None] = OrderedDict()
        self._saved_sizes = [380, 360]
        self._repeat = self.controller.repeat_mode()
        self.tray: QSystemTrayIcon | None = None
        self._eq_window: EqualizerWindow | None = None
        self._language_actions: dict[str, QAction] = {}

        # Radio internetowe — okno tworzymy dopiero przy pierwszym otwarciu.
        self._radio_window: RadioWindow | None = None
        self._radio_station: RadioStation | None = None
        self._radio_mode = False

        self.setAcceptDrops(True)
        self.setWindowIcon(make_app_icon())
        self.setMinimumSize(780, 540)
        self.resize(1020, 740)

        self._build_ui()
        self._create_actions()
        self._build_menus()
        self._connect_signals()
        self._setup_tray()
        self._restore_state()
        self._apply_eq_from_config()
        self._update_counts()

        # Okresowy zapis stanu — nawet po nagłym zamknięciu nic nie zginie.
        self._autosave = QTimer(self)
        self._autosave.setInterval(20000)
        self._autosave.timeout.connect(self._save_state)
        self._autosave.start()

    # =====================================================================
    # Budowa interfejsu
    # =====================================================================
    def _build_ui(self) -> None:
        root = QWidget(self)
        root.setObjectName("Root")
        self.setCentralWidget(root)

        outer = QVBoxLayout(root)
        outer.setContentsMargins(18, 12, 18, 8)
        outer.setSpacing(0)

        self.splitter = QSplitter(Qt.Orientation.Vertical, root)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(10)
        outer.addWidget(self.splitter)

        # --- górna część: informacje, widmo, sterowanie ---------------------
        player = QWidget(self.splitter)
        layout = QVBoxLayout(player)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(14)

        header = QHBoxLayout()
        header.setSpacing(16)
        self.cover = CoverWidget(76, player)
        header.addWidget(self.cover)

        info = QVBoxLayout()
        info.setSpacing(3)
        info.addStretch(1)
        self.lbl_title = QLabel(tr("Nic nie jest odtwarzane"), player)
        self.lbl_title.setObjectName("NowTitle")
        self.lbl_artist = QLabel(tr("Dodaj utwory do playlisty, aby zacząć"), player)
        self.lbl_artist.setObjectName("NowArtist")
        self.lbl_album = QLabel("", player)
        self.lbl_album.setObjectName("NowAlbum")
        info.addWidget(self.lbl_title)
        info.addWidget(self.lbl_artist)
        info.addWidget(self.lbl_album)
        info.addStretch(1)
        header.addLayout(info, 1)

        self.btn_radio = QPushButton("  " + tr("Radio"), player)
        self.btn_radio.setObjectName("RadioButton")
        self.btn_radio.setIcon(make_icon("radio", TEXT, 32))
        self.btn_radio.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_radio.setToolTip(tr("Radio internetowe (Ctrl+R)"))
        header.addWidget(self.btn_radio, 0, Qt.AlignmentFlag.AlignTop)
        layout.addLayout(header)

        self.spectrum = SpectrumWidget(player)
        layout.addWidget(self.spectrum, 1)

        seek_row = QHBoxLayout()
        seek_row.setSpacing(12)
        self.lbl_elapsed = TimeLabel("0:00", player)
        self.seek = SeekSlider(player)
        self.lbl_total = TimeLabel("0:00", player)
        seek_row.addWidget(self.lbl_elapsed)
        seek_row.addWidget(self.seek, 1)
        seek_row.addWidget(self.lbl_total)
        layout.addLayout(seek_row)

        controls = QHBoxLayout()
        controls.setSpacing(6)
        self.btn_shuffle = IconButton(
            "shuffle", player, tooltip=tr("Losowo (S)"), checkable=True
        )
        self.btn_repeat = IconButton("repeat", player, tooltip=tr("Powtarzanie (R)"))
        self.btn_prev = IconButton("prev", player, tooltip=tr("Poprzedni (Z)"))
        self.btn_play = PlayButton(player, tooltip=tr("Odtwórz / Pauza (Space)"))
        self.btn_next = IconButton("next", player, tooltip=tr("Następny (B)"))
        self.btn_stop = IconButton("stop", player, tooltip=tr("Stop (V)"), dim=True)

        controls.addWidget(self.btn_shuffle)
        controls.addStretch(1)
        controls.addWidget(self.btn_prev)
        controls.addWidget(self.btn_play)
        controls.addWidget(self.btn_next)
        controls.addWidget(self.btn_stop)
        controls.addStretch(1)

        self.btn_mute = IconButton("volume", player, tooltip=tr("Wycisz (M)"))
        self.vol = VolumeSlider(player)
        self.lbl_vol = QLabel("80%", player)
        self.lbl_vol.setObjectName("VolLabel")
        self.lbl_vol.setFixedWidth(38)
        self.lbl_vol.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        controls.addWidget(self.btn_mute)
        controls.addSpacing(4)
        controls.addWidget(self.vol)
        controls.addSpacing(6)
        controls.addWidget(self.lbl_vol)
        layout.addLayout(controls)

        self.splitter.addWidget(player)

        # --- dolna część: playlista -----------------------------------------
        self.playlist_panel = QWidget(self.splitter)
        panel = QVBoxLayout(self.playlist_panel)
        panel.setContentsMargins(0, 0, 0, 0)
        panel.setSpacing(8)

        bar = QHBoxLayout()
        bar.setSpacing(4)
        title = QLabel(tr("Playlista"), self.playlist_panel)
        title.setObjectName("SectionTitle")
        self.lbl_count = QLabel(track_count(0), self.playlist_panel)
        self.lbl_count.setObjectName("Badge")
        bar.addWidget(title)
        bar.addWidget(self.lbl_count)
        bar.addStretch(1)

        self.filter = FilterEdit(self.playlist_panel)
        self.filter.setPlaceholderText(tr("Filtruj utwory…  (F)"))
        self.filter.setClearButtonEnabled(True)
        self.filter.setFixedWidth(230)
        bar.addWidget(self.filter)
        bar.addSpacing(6)

        self.btn_add = IconButton(
            "plus", self.playlist_panel, size=32, icon_size=15,
            tooltip=tr("Dodaj pliki (Ctrl+O)"),
        )
        self.btn_folder = IconButton(
            "folder", self.playlist_panel, size=32, icon_size=15,
            tooltip=tr("Dodaj folder (Ctrl+Shift+O)"),
        )
        self.btn_remove = IconButton(
            "trash", self.playlist_panel, size=32, icon_size=15,
            tooltip=tr("Usuń zaznaczone (Delete)"),
        )
        self.btn_load = IconButton(
            "file", self.playlist_panel, size=32, icon_size=15,
            tooltip=tr("Wczytaj playlistę (Ctrl+L)"),
        )
        self.btn_save = IconButton(
            "save", self.playlist_panel, size=32, icon_size=15,
            tooltip=tr("Zapisz playlistę (Ctrl+S)"),
        )
        for button in (self.btn_add, self.btn_folder, self.btn_remove, self.btn_load, self.btn_save):
            bar.addWidget(button)
        panel.addLayout(bar)

        self.table = QTableView(self.playlist_panel)
        self.table.setModel(self.proxy)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setSortingEnabled(True)
        self.table.sortByColumn(0, Qt.SortOrder.AscendingOrder)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(32)

        header_view = self.table.horizontalHeader()
        header_view.setHighlightSections(False)
        header_view.setStretchLastSection(False)
        header_view.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        header_view.resizeSection(0, 46)
        header_view.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header_view.setSectionResizeMode(2, QHeaderView.ResizeMode.Interactive)
        header_view.resizeSection(2, 190)
        header_view.setSectionResizeMode(3, QHeaderView.ResizeMode.Interactive)
        header_view.resizeSection(3, 190)
        header_view.setSectionResizeMode(4, QHeaderView.ResizeMode.Fixed)
        header_view.resizeSection(4, 64)
        header_view.setSortIndicator(0, Qt.SortOrder.AscendingOrder)
        panel.addWidget(self.table, 1)

        self.splitter.addWidget(self.playlist_panel)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setSizes([380, 340])

        status = QStatusBar(self)
        self.setStatusBar(status)
        self.status_count = QLabel("", self)
        self.status_count.setStyleSheet(f"color: {MUTED}; padding-right: 8px;")
        status.addPermanentWidget(self.status_count)

    # =====================================================================
    # Akcje i menu
    # =====================================================================
    def _action(self, text, shortcut, slot, icon_name=None, checkable=False) -> QAction:
        action = QAction(text, self)
        if shortcut is not None:
            sequence = QKeySequence(shortcut) if isinstance(shortcut, str) else QKeySequence(shortcut)
            action.setShortcut(sequence)
            action.setShortcutContext(Qt.ShortcutContext.WindowShortcut)
        if icon_name:
            action.setIcon(make_icon(icon_name, TEXT, 64))
        action.setCheckable(checkable)
        action.triggered.connect(slot)
        self.addAction(action)
        return action

    def _guarded(self, function):
        """Skróty jednoklawiszowe nie działają, gdy piszemy w polu filtra."""

        def wrapper(*_args):
            focused = QApplication.focusWidget()
            if isinstance(focused, FilterEdit):
                return
            function()

        return wrapper

    def _create_actions(self) -> None:
        self.act_play_pause = self._action(
            tr("Odtwórz / pauza"), Qt.Key.Key_Space, self._guarded(self._toggle_play)
        )
        self.act_play = self._action(tr("Odtwórz"), "X", self._guarded(self._play_current))
        self.act_pause = self._action(tr("Pauza"), "C", self._guarded(self._pause))
        self.act_stop = self._action(tr("Stop"), "V", self._guarded(self._stop))
        self.act_next = self._action(tr("Następny"), "B", self._guarded(self.controller.next))
        self.act_prev = self._action(tr("Poprzedni"), "Z", self._guarded(self.controller.previous))

        self.act_seek_back = self._action(
            tr("Przewiń 5 s do tyłu"), "Left", self._guarded(lambda: self._seek_by(-5000))
        )
        self.act_seek_fwd = self._action(
            tr("Przewiń 5 s do przodu"), "Right", self._guarded(lambda: self._seek_by(5000))
        )
        self.act_seek_back_long = self._action(
            tr("Przewiń 30 s do tyłu"), "Shift+Left", self._guarded(lambda: self._seek_by(-30000))
        )
        self.act_seek_fwd_long = self._action(
            tr("Przewiń 30 s do przodu"), "Shift+Right", self._guarded(lambda: self._seek_by(30000))
        )
        self.act_vol_up = self._action(
            tr("Głośniej"), "Up", self._guarded(lambda: self._change_volume(5))
        )
        self.act_vol_down = self._action(
            tr("Ciszej"), "Down", self._guarded(lambda: self._change_volume(-5))
        )
        self.act_mute = self._action(tr("Wycisz"), "M", self._guarded(self._toggle_mute))
        self.act_shuffle = self._action(tr("Tryb losowy"), "S", self._guarded(self.btn_shuffle.toggle))
        self.act_repeat = self._action(tr("Powtarzanie"), "R", self._guarded(self._cycle_repeat))
        self.act_filter = self._action(tr("Filtruj playlistę"), "F", self._guarded(self._focus_filter))
        self.act_play_selected = self._action(
            tr("Odtwórz zaznaczony"), Qt.Key.Key_Return, self._guarded(self._play_selected)
        )
        self.act_remove = self._action(
            tr("Usuń z playlisty"), Qt.Key.Key_Delete, self._guarded(self._remove_selected)
        )

        self.act_open = self._action(tr("Otwórz pliki…"), "Ctrl+O", self.add_files, "plus")
        self.act_add_folder = self._action(
            tr("Dodaj folder…"), "Ctrl+Shift+O", self.add_folder, "folder"
        )
        self.act_load = self._action(tr("Wczytaj playlistę…"), "Ctrl+L", self.load_playlist, "file")
        self.act_save = self._action(tr("Zapisz playlistę…"), "Ctrl+S", self.save_playlist, "save")
        self.act_radio = self._action(
            tr("Radio internetowe…"), "Ctrl+R", self.open_radio, "radio"
        )
        self.act_radio_favorites = self._action(
            tr("Ulubione stacje…"), "Ctrl+Shift+R", lambda: self.open_radio(True), "radio"
        )
        self.act_equalizer = self._action(tr("Korektor…"), "Ctrl+E", self.open_equalizer)
        self.act_quit = self._action(tr("Wyjście"), "Ctrl+Q", self._quit)

        self.act_help = self._action(
            tr("Skróty klawiszowe"), Qt.Key.Key_F1, lambda: show_shortcuts(self)
        )
        self.act_about = self._action(tr("O programie"), None, lambda: show_about(self))

        self.act_playlist = self._action(
            tr("Pokaż playlistę"), Qt.Key.Key_F8, self._toggle_playlist, checkable=True
        )
        self.act_playlist.setChecked(True)
        self.act_tray = self._action(
            tr("Zamykaj do zasobnika"), None, self._set_close_to_tray, checkable=True
        )

        self.act_media_play = self._action(
            tr("Media: odtwórz / pauza"), Qt.Key.Key_MediaPlay, self._toggle_play
        )
        self.act_media_next = self._action(
            tr("Media: następny"), Qt.Key.Key_MediaNext, self.controller.next
        )
        self.act_media_prev = self._action(
            tr("Media: poprzedni"), Qt.Key.Key_MediaPrevious, self.controller.previous
        )
        self.act_media_stop = self._action(
            tr("Media: stop"), Qt.Key.Key_MediaStop, self.controller.stop
        )

    def _build_menus(self) -> None:
        menu_bar = self.menuBar()

        file_menu = menu_bar.addMenu(tr("Plik"))
        file_menu.addAction(self.act_open)
        file_menu.addAction(self.act_add_folder)
        file_menu.addSeparator()
        file_menu.addAction(self.act_load)
        file_menu.addAction(self.act_save)
        file_menu.addSeparator()
        file_menu.addAction(self.act_quit)

        play_menu = menu_bar.addMenu(tr("Odtwarzanie"))
        play_menu.addAction(self.act_play_pause)
        play_menu.addAction(self.act_play)
        play_menu.addAction(self.act_pause)
        play_menu.addAction(self.act_stop)
        play_menu.addSeparator()
        play_menu.addAction(self.act_next)
        play_menu.addAction(self.act_prev)
        play_menu.addSeparator()
        play_menu.addAction(self.act_seek_back)
        play_menu.addAction(self.act_seek_fwd)
        play_menu.addSeparator()
        play_menu.addAction(self.act_vol_up)
        play_menu.addAction(self.act_vol_down)
        play_menu.addAction(self.act_mute)
        play_menu.addSeparator()
        play_menu.addAction(self.act_shuffle)
        play_menu.addAction(self.act_repeat)

        radio_menu = menu_bar.addMenu(tr("Radio"))
        radio_menu.addAction(self.act_radio)
        radio_menu.addAction(self.act_radio_favorites)

        view_menu = menu_bar.addMenu(tr("Widok"))
        view_menu.addAction(self.act_playlist)
        view_menu.addAction(self.act_filter)
        view_menu.addSeparator()
        view_menu.addAction(self.act_tray)

        tools_menu = menu_bar.addMenu(tr("Narzędzia"))
        tools_menu.addAction(self.act_equalizer)
        lang_menu = tools_menu.addMenu(tr("Język"))
        group = QActionGroup(self)
        current = language()
        self._language_actions.clear()
        for code, name in LANGUAGES.items():
            action = QAction(name, self)
            action.setCheckable(True)
            action.setChecked(code == current)
            action.setData(code)
            action.triggered.connect(lambda _checked=False, c=code: self._change_language(c))
            group.addAction(action)
            lang_menu.addAction(action)
            self._language_actions[code] = action

        help_menu = menu_bar.addMenu(tr("Pomoc"))
        help_menu.addAction(self.act_help)
        help_menu.addAction(self.act_about)

    # =====================================================================
    # Połączenia sygnałów
    # =====================================================================
    def _connect_signals(self) -> None:
        self.btn_play.clicked.connect(self._toggle_play)
        self.btn_prev.clicked.connect(self.controller.previous)
        self.btn_next.clicked.connect(self.controller.next)
        self.btn_stop.clicked.connect(self._stop)
        self.btn_shuffle.toggled.connect(self._apply_shuffle)
        self.btn_repeat.clicked.connect(self._cycle_repeat)
        self.btn_mute.clicked.connect(self._toggle_mute)
        self.btn_add.clicked.connect(self.add_files)
        self.btn_folder.clicked.connect(self.add_folder)
        self.btn_remove.clicked.connect(self._remove_selected)
        self.btn_load.clicked.connect(self.load_playlist)
        self.btn_save.clicked.connect(self.save_playlist)
        self.btn_radio.clicked.connect(self.open_radio)

        self.vol.valueChanged.connect(self._on_volume_changed)
        self.seek.seekRequested.connect(self.engine.seek)
        self.filter.textChanged.connect(self.proxy.set_filter)
        self.filter.returnPressed.connect(self._play_first_visible)
        self.filter.escapePressed.connect(self._clear_filter)
        self.table.doubleClicked.connect(self._on_double_click)
        self.table.customContextMenuRequested.connect(self._show_table_menu)

        self.engine.positionChanged.connect(self._on_position)
        self.engine.durationChanged.connect(self._on_duration)
        self.engine.playingChanged.connect(self._on_playing)
        self.engine.errorOccurred.connect(self._on_engine_error)
        self.engine.samplesReady.connect(self.spectrum.set_samples)
        self.engine.mutedChanged.connect(self._on_muted_changed)
        self.controller.trackChanged.connect(self._on_track_changed)

        self.model.rowsInserted.connect(self._on_rows_inserted)
        self.model.rowsRemoved.connect(self._on_rows_removed)
        self.model.modelReset.connect(self._on_model_reset)

        self._signals.metadataBatch.connect(self._on_metadata_batch)
        self._signals.coverReady.connect(self._on_cover_ready)

        self.equalizer.failed.connect(self._on_eq_failed)
        self.spectrum.set_supported(self.engine.spectrum_supported)

    # =====================================================================
    # Zasobnik systemowy
    # =====================================================================
    def _setup_tray(self) -> None:
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray = QSystemTrayIcon(make_app_icon(), self)
        self.tray.setToolTip(APP_NAME)

        menu = QMenu(self)
        self._tray_menu = menu
        menu.addAction(tr("Odtwórz / pauza"), self._toggle_play)
        menu.addAction(tr("Następny"), self.controller.next)
        menu.addAction(tr("Poprzedni"), self.controller.previous)
        menu.addSeparator()
        menu.addAction(tr("Radio internetowe…"), lambda: self.open_radio(False))
        menu.addAction(tr("Pokaż okno"), self._show_window)
        menu.addSeparator()
        menu.addAction(tr("Zakończ"), self._quit)

        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._on_tray_activated)
        self.tray.show()

    # =====================================================================
    # Przywracanie i zapis stanu
    # =====================================================================
    def _restore_state(self) -> None:
        geometry = self.config.get("geometry")
        if geometry:
            try:
                self.restoreGeometry(QByteArray.fromBase64(str(geometry).encode("ascii")))
            except Exception:
                pass

        splitter_state = self.config.get("splitter")
        if splitter_state:
            try:
                self.splitter.restoreState(QByteArray.fromBase64(str(splitter_state).encode("ascii")))
            except Exception:
                pass

        volume = max(0, min(100, int(self.config.get("volume", 80))))
        self.vol.blockSignals(True)
        self.vol.setValue(volume)
        self.vol.blockSignals(False)
        self.lbl_vol.setText(f"{volume}%")
        self.engine.set_volume(volume)
        if self.config.get("muted"):
            self.engine.set_muted(True)

        self.act_tray.setChecked(bool(self.config.get("close_to_tray", False)))

        shuffle = bool(self.config.get("shuffle", False))
        self.btn_shuffle.blockSignals(True)
        self.btn_shuffle.setChecked(shuffle)
        self.btn_shuffle.blockSignals(False)
        self.controller.set_shuffle(shuffle)

        self._repeat = int(self.config.get("repeat", 0)) % 3
        self.controller.set_repeat(self._repeat)
        self._update_repeat_button()

        visible = bool(self.config.get("playlist_visible", True))
        self.playlist_panel.setVisible(visible)
        self.act_playlist.setChecked(visible)

        paths = [
            path
            for path in self.config.get("playlist", [])
            if isinstance(path, str) and os.path.isfile(path)
        ]
        if paths:
            added = self.model.add_paths(paths)
            self._enrich(added)
            current = int(self.config.get("current", -1))
            if 0 <= current < self.model.rowCount():
                position = max(0, int(self.config.get("position", 0)))
                self.controller.play_index(current, autoplay=False, position_ms=position)
                self.seek.blockSignals(True)
                self.seek.setValue(position)
                self.seek.blockSignals(False)
                self.lbl_elapsed.setText(format_duration(position))

        self._on_muted_changed(self.engine.is_muted())

    def _save_state(self) -> None:
        self.config.set("playlist", self.model.paths())
        self.config.set("current", self.controller.current_index)
        self.config.set(
            "position",
            self.engine.position() if self.controller.current_index >= 0 else 0,
        )
        self.config.set("volume", self.vol.value())
        self.config.set("muted", self.engine.is_muted())
        self.config.set("shuffle", self.btn_shuffle.isChecked())
        self.config.set("repeat", self._repeat)
        self.config.set("close_to_tray", self.act_tray.isChecked())
        self.config.set("playlist_visible", self.playlist_panel.isVisible())
        self.config.set("language", language())
        try:
            self.config.set(
                "geometry", bytes(self.saveGeometry().toBase64()).decode("ascii")
            )
            self.config.set(
                "splitter", bytes(self.splitter.saveState().toBase64()).decode("ascii")
            )
        except Exception:
            pass
        self.config.save()

    def _set_close_to_tray(self, enabled: bool) -> None:
        self.config.set("close_to_tray", bool(enabled))

    def closeEvent(self, event) -> None:  # noqa: N802
        if self.act_tray.isChecked() and self.tray is not None:
            self._save_state()
            event.ignore()
            self.hide()
            self.tray.showMessage(
                APP_NAME,
                tr("Odtwarzacz działa w zasobniku systemowym."),
                QSystemTrayIcon.MessageIcon.Information,
                2500,
            )
            return
        self._save_state()
        event.accept()

    def _quit(self) -> None:
        self._save_state()
        if self.tray is not None:
            self.tray.hide()
        QApplication.quit()

    def _show_window(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _on_tray_activated(self, reason) -> None:
        if reason in (
            QSystemTrayIcon.ActivationReason.Trigger,
            QSystemTrayIcon.ActivationReason.DoubleClick,
        ):
            self._show_window()

    # =====================================================================
    # Radio internetowe
    # =====================================================================
    def _ensure_radio_window(self) -> RadioWindow:
        if self._radio_window is None:
            self._radio_window = RadioWindow(self.config, self.engine, self)
            self._radio_window.stationActivated.connect(self._play_radio_station)
            self._radio_window.currentTrackChanged.connect(
                self._on_radio_track_changed
            )
        return self._radio_window

    def open_radio(self, favorites: bool = False, *_args) -> None:
        """Otwiera okno radia (opcjonalnie od razu zakładkę ulubionych)."""
        window = self._ensure_radio_window()
        if favorites:
            window.show_favorites()
        window.show()
        window.raise_()
        window.activateWindow()

    def _play_radio_station(self, station: RadioStation, url: str) -> None:
        """Przełącza odtwarzanie na wybraną stację radiową."""
        self._radio_mode = True
        self._radio_station = station

        # Odpinamy playlistę (bez zatrzymywania silnika) i puszczamy strumień.
        self.controller.detach_stream()
        self.engine.play_url(url)

        self.cover.set_placeholder("radio")
        self.cover.set_pixmap(None)
        self.lbl_title.setText(station.name)
        self.lbl_artist.setText(station.current_track or tr("Radio internetowe"))
        details = " • ".join(
            part for part in (station.genre, station.quality) if part
        )
        self.lbl_album.setText(details)
        self.lbl_album.setVisible(bool(details))
        self.setWindowTitle(f"{station.name} • {APP_NAME}")

        self.seek.blockSignals(True)
        self.seek.setRange(0, 0)
        self.seek.setValue(0)
        self.seek.blockSignals(False)
        self.seek.setEnabled(False)
        self.lbl_elapsed.set_highlight(True)
        self.lbl_elapsed.setText(tr("NA ŻYWO"))
        self.lbl_total.setText("")

        if self._radio_window is not None:
            self._radio_window.set_now_playing(station, url)
        self.statusBar().showMessage(tr("Radio: {name}", name=station.name), 6000)

    def _on_radio_track_changed(self, station_id: str, title: str) -> None:
        """Aktualizuje tytuł piosenki granej na antenie."""
        if not self._radio_mode or self._radio_station is None:
            return
        if station_id != self._radio_station.id:
            return
        self._radio_station.current_track = title
        self.lbl_artist.setText(title)

    def _leave_radio_mode(self) -> None:
        """Wychodzi z trybu radia (bez zatrzymywania silnika)."""
        if not self._radio_mode:
            return
        self._radio_mode = False
        self._radio_station = None
        self.seek.setEnabled(True)
        self.cover.set_placeholder("note")
        self.lbl_elapsed.set_highlight(False)
        if self._radio_window is not None:
            self._radio_window.set_now_playing(None)

    # =====================================================================
    # Odtwarzanie
    # =====================================================================
    def _toggle_play(self, *_args) -> None:
        if self._radio_mode:
            if self.engine.is_playing():
                self.engine.pause()
            else:
                self.engine.play()
            return
        self.controller.toggle()

    def _play_current(self) -> None:
        if self._radio_mode:
            self.engine.play()
            return
        if self.controller.current_index >= 0:
            self.controller.play_index(self.controller.current_index)
        else:
            self.controller.play_first()

    def _pause(self) -> None:
        if self.engine.is_playing():
            self.engine.pause()

    def _stop(self, *_args) -> None:
        was_radio = self._radio_mode
        self._leave_radio_mode()
        self.controller.stop()

        if was_radio:
            self._show_idle()
            return

        # Przy zwykłym utworze zostawiamy jego nazwę na ekranie (jak w Winampie),
        # żeby po ponownym włączeniu informacje były spójne.
        self.seek.blockSignals(True)
        self.seek.setValue(0)
        self.seek.blockSignals(False)
        self.lbl_elapsed.setText("0:00")
        self.btn_play.set_playing(False)
        self.spectrum.set_playing(False)

    def _show_idle(self) -> None:
        """Przywraca ekran „nic nie jest odtwarzane”."""
        self.lbl_title.setText(tr("Nic nie jest odtwarzane"))
        self.lbl_artist.setText(tr("Dodaj utwory do playlisty, aby zacząć"))
        self.lbl_album.setText("")
        self.lbl_album.setVisible(False)
        self.cover.set_pixmap(None)
        self.cover.set_placeholder("note")
        self.seek.blockSignals(True)
        self.seek.setRange(0, 0)
        self.seek.setValue(0)
        self.seek.blockSignals(False)
        self.seek.setEnabled(True)
        self.lbl_elapsed.set_highlight(False)
        self.lbl_elapsed.setText("0:00")
        self.lbl_total.setText("0:00")
        self.btn_play.set_playing(False)
        self.spectrum.set_playing(False)
        self.setWindowTitle(APP_NAME)

    def _seek_by(self, delta_ms: int) -> None:
        if self._radio_mode or not self.engine.has_source():
            return
        limit = self.engine.duration() or self.seek.maximum()
        target = max(0, min(int(limit), self.engine.position() + int(delta_ms)))
        self.engine.seek(target)
        self.seek.blockSignals(True)
        self.seek.setValue(target)
        self.seek.blockSignals(False)
        self.lbl_elapsed.setText(format_duration(target))

    def _change_volume(self, delta: int) -> None:
        self.vol.setValue(max(0, min(100, self.vol.value() + int(delta))))

    def _on_volume_changed(self, value: int) -> None:
        self.engine.set_volume(int(value))
        if value > 0 and self.engine.is_muted():
            self.engine.set_muted(False)
        self._update_mute_icon()

    def _toggle_mute(self, *_args) -> None:
        self.engine.set_muted(not self.engine.is_muted())

    def _on_muted_changed(self, muted: bool) -> None:
        self._update_mute_icon()

    def _update_mute_icon(self) -> None:
        muted = self.engine.is_muted()
        self.btn_mute.set_icon_name("mute" if muted else "volume")
        self.btn_mute.setToolTip(tr("Włącz dźwięk (M)") if muted else tr("Wycisz (M)"))
        self.lbl_vol.setText("0%" if muted else f"{self.vol.value()}%")

    def _apply_shuffle(self, enabled: bool) -> None:
        self.controller.set_shuffle(bool(enabled))
        self.statusBar().showMessage(
            tr("Tryb losowy: włączony") if enabled else tr("Tryb losowy: wyłączony"), 3000
        )

    def _cycle_repeat(self, *_args) -> None:
        self._repeat = (self._repeat + 1) % 3
        self.controller.set_repeat(self._repeat)
        self._update_repeat_button()
        names = (tr("wyłączone"), tr("całej playlisty"), tr("jednego utworu"))
        self.statusBar().showMessage(tr("Powtarzanie: {mode}", mode=names[self._repeat]), 3000)

    def _update_repeat_button(self) -> None:
        names = (tr("wyłączone"), tr("całej playlisty"), tr("jednego utworu"))
        self.btn_repeat.set_icon_name("repeat_one" if self._repeat == 2 else "repeat")
        self.btn_repeat.setChecked(self._repeat != 0)
        self.btn_repeat.setToolTip(tr("Powtarzanie: {mode}", mode=names[self._repeat]) + " (R)")

    def _play_selected(self) -> None:
        rows = self._selected_source_rows()
        if rows:
            self._start_index(rows[0])
        else:
            self.controller.play_first()

    def _play_first_visible(self) -> None:
        if self.proxy.rowCount() > 0:
            source = self.proxy.mapToSource(self.proxy.index(0, 0))
            self._start_index(source.row())

    def _on_double_click(self, index) -> None:
        self._start_index(self.proxy.mapToSource(index).row())

    def _start_index(self, source_row: int) -> None:
        if 0 <= source_row < self.model.rowCount():
            self.controller.play_index(source_row)

    # =====================================================================
    # Reakcje na sygnały silnika
    # =====================================================================
    def _on_track_changed(self, track: Track | None) -> None:
        if track is None:
            # W trybie radia sygnał None pochodzi z odpięcia playlisty —
            # nie chcemy wtedy kasować informacji o stacji.
            if self._radio_mode:
                return
            self._show_idle()
            return

        self._leave_radio_mode()
        self.cover.set_placeholder("note")
        self.lbl_title.setText(track.title)
        self.lbl_artist.setText(track.artist or tr("Nieznany wykonawca"))
        self.lbl_album.setText(track.album)
        self.lbl_album.setVisible(bool(track.album))
        if track.artist:
            self.setWindowTitle(f"{track.title} — {track.artist} • {APP_NAME}")
        else:
            self.setWindowTitle(f"{track.title} • {APP_NAME}")

        self.seek.blockSignals(True)
        self.seek.setRange(0, max(0, track.duration_ms))
        self.seek.setValue(0)
        self.seek.blockSignals(False)
        self.lbl_total.setText(format_duration(track.duration_ms))
        self.lbl_elapsed.setText("0:00")

        self._load_cover(track.path)
        self._scroll_to_current()

    def _on_position(self, position_ms: int) -> None:
        if self._radio_mode:
            return
        if not self.seek.dragging:
            self.seek.blockSignals(True)
            self.seek.setValue(int(position_ms))
            self.seek.blockSignals(False)
        self.lbl_elapsed.setText(format_duration(int(position_ms)))

    def _on_duration(self, duration_ms: int) -> None:
        if self._radio_mode or duration_ms <= 0:
            return
        track = self.controller.current_track()
        if track is not None and track.duration_ms <= 0:
            self.model.update_duration(track.path, int(duration_ms))
        self.seek.setMaximum(int(duration_ms))
        self.lbl_total.setText(format_duration(int(duration_ms)))

    def _on_playing(self, playing: bool) -> None:
        self.btn_play.set_playing(bool(playing))
        self.spectrum.set_playing(bool(playing))

    def _on_engine_error(self, message: str) -> None:
        if self._radio_mode and self._radio_station is not None:
            self.statusBar().showMessage(
                tr("Nie można odtworzyć stacji „{name}”: {message}",
                   name=self._radio_station.name, message=message),
                8000,
            )
        else:
            track = self.controller.current_track()
            name = track.title if track is not None else tr("utwór")
            self.statusBar().showMessage(
                tr("Nie można odtworzyć „{name}”: {message}", name=name, message=message),
                8000,
            )
        self.btn_play.set_playing(False)
        self.spectrum.set_playing(False)

    # =====================================================================
    # Okładki
    # =====================================================================
    def _load_cover(self, path: str) -> None:
        if path in self._cover_cache:
            self.cover.set_pixmap(self._cover_cache[path])
            return
        self.cover.set_pixmap(None)
        self._pool.start(CoverTask(path, self._signals))

    def _on_cover_ready(self, path: str, data: bytes, mime: str) -> None:
        pixmap: QPixmap | None = None
        if data:
            candidate = QPixmap()
            if candidate.loadFromData(data):
                pixmap = candidate
        self._cover_cache[path] = pixmap
        self._cover_cache.move_to_end(path)
        while len(self._cover_cache) > 80:
            self._cover_cache.popitem(last=False)

        current = self.controller.current_track()
        if current is not None and current.path == path:
            self.cover.set_pixmap(pixmap)

    def _scroll_to_current(self) -> None:
        index = self.controller.current_index
        if index < 0:
            return
        proxy_index = self.proxy.mapFromSource(self.model.index(index, 0))
        if proxy_index.isValid():
            self.table.scrollTo(
                proxy_index, QAbstractItemView.ScrollHint.PositionAtCenter
            )

    # =====================================================================
    # Playlista
    # =====================================================================
    def add_files(self) -> None:
        start_dir = str(self.config.get("last_dir") or Path.home())
        files, _ = QFileDialog.getOpenFileNames(
            self, tr("Dodaj pliki audio"), start_dir, AUDIO_FILTER
        )
        if not files:
            return
        self.config.set("last_dir", str(Path(files[0]).parent))
        self.add_paths(files)

    def add_folder(self) -> None:
        start_dir = str(self.config.get("last_dir") or Path.home())
        folder = QFileDialog.getExistingDirectory(self, tr("Dodaj folder z muzyką"), start_dir)
        if not folder:
            return
        self.config.set("last_dir", folder)
        self.add_paths([folder])

    def add_paths(self, paths: list[str]) -> None:
        files: list[str] = []
        for raw in paths:
            path = Path(raw)
            if path.is_dir():
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                try:
                    files.extend(scan_folder(path))
                finally:
                    QApplication.restoreOverrideCursor()
            elif path.is_file() and is_audio_file(path):
                files.append(str(path))

        unique = list(dict.fromkeys(files))
        if not unique:
            self.statusBar().showMessage(tr("Nie znaleziono plików audio."), 4000)
            return

        added = self.model.add_paths(unique)
        if not added:
            self.statusBar().showMessage(tr("Te pliki są już na playliście."), 4000)
            return

        self._enrich(added)
        self._update_counts()
        self.statusBar().showMessage(tr("Dodano: {count}.", count=track_count(len(added))), 4000)

        if self.controller.current_index < 0 and self.proxy.rowCount() > 0:
            self.table.selectRow(0)

    def load_playlist(self) -> None:
        start_dir = str(self.config.get("last_dir") or Path.home())
        path, _ = QFileDialog.getOpenFileName(
            self, tr("Wczytaj playlistę"), start_dir, PLAYLIST_FILTER
        )
        if not path:
            return
        try:
            tracks = load_playlist(path)
        except Exception as error:  # noqa: BLE001
            QMessageBox.warning(
                self, tr("Nie można wczytać playlisty"),
                tr("Wystąpił błąd:\n{error}", error=error),
            )
            return

        existing = [
            track.path for track in tracks
            if track.path.startswith(("http://", "https://")) or os.path.isfile(track.path)
        ]
        missing = len(tracks) - len(existing)
        added = self.model.add_paths(existing)
        self._enrich(added)
        self._update_counts()

        message = tr("Wczytano: {count}.", count=track_count(len(added)))
        if missing:
            message += " " + tr("Pominięto {count} nieistniejących plików.", count=missing)
        self.statusBar().showMessage(message, 6000)

    def save_playlist(self) -> None:
        if self.model.rowCount() == 0:
            self.statusBar().showMessage(
                tr("Playlista jest pusta — nie ma czego zapisać."), 4000
            )
            return
        start_dir = str(self.config.get("last_dir") or Path.home())
        default_path = str(Path(start_dir) / "playlista.m3u8")
        path, selected = QFileDialog.getSaveFileName(
            self, tr("Zapisz playlistę"), default_path, PLAYLIST_FILTER
        )
        if not path:
            return
        if not Path(path).suffix:
            path += ".pls" if "PLS" in selected else ".m3u8"
        try:
            save_playlist(self.model.tracks(), path)
        except OSError as error:
            QMessageBox.warning(self, tr("Nie można zapisać playlisty"), str(error))
            return
        self.statusBar().showMessage(tr("Zapisano playlistę: {path}", path=path), 5000)

    def _selected_source_rows(self) -> list[int]:
        selection = self.table.selectionModel()
        if selection is None:
            return []
        return sorted(
            {self.proxy.mapToSource(index).row() for index in selection.selectedRows()}
        )

    def _remove_selected(self) -> None:
        rows = self._selected_source_rows()
        if not rows:
            return
        self.controller.prepare_removal(set(rows))
        self.model.remove_rows(rows)
        self._update_counts()

    def _clear_playlist(self) -> None:
        if self.model.rowCount() == 0:
            return
        answer = QMessageBox.question(
            self,
            tr("Wyczyścić playlistę?"),
            tr("Czy na pewno usunąć wszystkie utwory z playlisty?\nPliki na dysku pozostaną nietknięte."),
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.controller.reset_current()
        self.model.clear()
        self._update_counts()

    def _show_table_menu(self, position) -> None:
        rows = self._selected_source_rows()
        menu = QMenu(self)
        if rows:
            menu.addAction(tr("Odtwórz"), self._play_selected)
            menu.addAction(
                tr("Pokaż w folderze"), lambda: self._show_in_folder(rows[0])
            )
            menu.addSeparator()
            menu.addAction(tr("Usuń z playlisty"), self._remove_selected)
        else:
            menu.addAction(tr("Dodaj pliki…"), self.add_files)
        menu.addSeparator()
        menu.addAction(tr("Wyczyść playlistę"), self._clear_playlist)
        menu.exec(self.table.viewport().mapToGlobal(position))

    def _show_in_folder(self, row: int) -> None:
        track = self.model.track_at(row)
        if track is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(track.path).parent)))

    def _focus_filter(self) -> None:
        self.filter.setFocus()
        self.filter.selectAll()

    def _clear_filter(self) -> None:
        self.filter.clear()
        self.table.setFocus()

    def _toggle_playlist(self, visible: bool) -> None:
        visible = bool(visible)
        self.playlist_panel.setVisible(visible)
        self.act_playlist.setChecked(visible)
        self.config.set("playlist_visible", visible)

    # =====================================================================
    # Reakcje na zmiany modelu i metadanych
    # =====================================================================
    def _on_rows_inserted(self, *_args) -> None:
        self.controller.rebuild()
        self._update_counts()

    def _on_rows_removed(self, *_args) -> None:
        if self.controller.current_index >= self.model.rowCount():
            self.controller.reset_current()
        self.controller.rebuild()
        self._update_counts()

    def _on_model_reset(self) -> None:
        self.controller.rebuild()
        self._update_counts()

    def _enrich(self, paths: list[str]) -> None:
        if paths:
            self._pool.start(MetadataTask(paths, self._signals))

    def _on_metadata_batch(self, batch: list) -> None:
        current = self.controller.current_track()
        current_path = current.path if current is not None else None
        refresh_current = False

        for info in batch:
            self.model.update_metadata(info)
            if current_path is not None and info.path == current_path:
                refresh_current = True

        self._update_counts()
        if refresh_current:
            self._on_track_changed(self.controller.current_track())

    def _update_counts(self) -> None:
        count = self.model.rowCount()
        label = track_count(count)
        self.lbl_count.setText(label)

        total = self.model.total_duration_ms()
        text = label
        if total:
            text += f"  •  {format_duration(total)}"
        self.status_count.setText(text)

    # =====================================================================
    # Korektor i język
    # =====================================================================
    def open_equalizer(self, *_args) -> None:
        if self._eq_window is None:
            self._eq_window = EqualizerWindow(self.equalizer, self.config, self)
        self._eq_window.show()
        self._eq_window.raise_()
        self._eq_window.activateWindow()

    def _apply_eq_from_config(self) -> None:
        gains = self.config.get("eq_gains", [0] * 10)
        if not isinstance(gains, list):
            gains = [0] * 10
        self.equalizer.set_gains(gains)
        self.equalizer.set_preamp(int(self.config.get("eq_preamp", 0)))
        if bool(self.config.get("eq_enabled", False)):
            if not self.equalizer.set_enabled(True):
                self.config.set("eq_enabled", False)
                self.config.save()

    def _on_eq_failed(self, message: str) -> None:
        self.config.set("eq_enabled", False)
        self.config.save()
        if self._eq_window is not None:
            try:
                self._eq_window.chk_enabled.setChecked(False)
            except Exception:
                pass
        self.statusBar().showMessage(
            tr("Nie udało się włączyć korektora: {error}", error=message), 7000
        )

    def _change_language(self, code: str) -> None:
        code = str(code)
        if code == language():
            return
        answer = QMessageBox.question(
            self,
            tr("Zmiana języka"),
            tr("Aby zmienić język, program uruchomi się ponownie. Kontynuować?"),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        current = language()
        if answer != QMessageBox.StandardButton.Yes:
            if current in self._language_actions:
                self._language_actions[current].setChecked(True)
            if code in self._language_actions:
                self._language_actions[code].setChecked(False)
            return
        self.config.set("language", code)
        self.config.save()
        self._restart_app()

    def _restart_app(self) -> None:
        self._save_state()
        if self.tray is not None:
            self.tray.hide()
        program = sys.executable
        args = ["-m", "linamp"]
        workdir = str(Path(__file__).resolve().parent.parent)
        try:
            started = QProcess.startDetached(program, args, workdir)
        except Exception:
            started = False
        if started:
            QApplication.quit()
        else:
            QMessageBox.warning(
                self,
                tr("Zmiana języka"),
                tr("Nie udało się uruchomić programu ponownie. Zamknij i otwórz LinAmp ręcznie."),
            )

    # =====================================================================
    # Przeciąganie plików na okno
    # =====================================================================
    def dragEnterEvent(self, event) -> None:  # noqa: N802
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dropEvent(self, event) -> None:  # noqa: N802
        urls = event.mimeData().urls()
        paths = [url.toLocalFile() for url in urls if url.isLocalFile()]
        if paths:
            self.add_paths(paths)
            event.acceptProposedAction()
        else:
            super().dropEvent(event)

