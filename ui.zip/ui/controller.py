"""Sterowanie kolejnością odtwarzania: następny/poprzedni, losowo, powtarzanie."""

from __future__ import annotations

import random

from PySide6.QtCore import QObject, Signal

from ..audio import AudioEngine
from ..config import Config
from ..playlist import PlaylistModel, Track


class PlaybackController(QObject):
    """Łączy playlistę z silnikiem audio i pilnuje kolejności utworów."""

    trackChanged = Signal(object)  # Track albo None

    def __init__(
        self,
        model: PlaylistModel,
        engine: AudioEngine,
        config: Config,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._model = model
        self._engine = engine
        self._config = config
        self._current = -1
        self._order: list[int] = []
        self._order_pos = -1
        self._stream_mode = False
        self._shuffle = bool(config.get("shuffle", False))
        self._repeat = int(config.get("repeat", 0)) % 3

        self._engine.finished.connect(self._on_finished)

    # --- informacje ---------------------------------------------------------
    @property
    def current_index(self) -> int:
        return self._current

    def current_track(self) -> Track | None:
        return self._model.track_at(self._current)

    def repeat_mode(self) -> int:
        return self._repeat

    def shuffle(self) -> bool:
        return self._shuffle

    # --- ustawienia trybów --------------------------------------------------
    def set_repeat(self, mode: int) -> None:
        self._repeat = int(mode) % 3

    def set_shuffle(self, enabled: bool) -> None:
        self._shuffle = bool(enabled)
        self.rebuild()

    # --- kolejność ----------------------------------------------------------
    def rebuild(self) -> None:
        """Przebudowuje kolejność po zmianie playlisty, z zachowaniem bieżącego utworu."""
        count = self._model.rowCount()
        if count == 0:
            self._order = []
            self._order_pos = -1
            return

        current = self.current_track()
        current_row = self._model.row_of(current.path) if current else -1

        if self._shuffle:
            order = list(range(count))
            random.shuffle(order)
            if current_row >= 0:
                order.remove(current_row)
                order.insert(0, current_row)
            self._order = order
            self._order_pos = 0 if current_row >= 0 else -1
        else:
            self._order = list(range(count))
            self._order_pos = current_row

    def _sync_order_position(self) -> None:
        try:
            self._order_pos = self._order.index(self._current)
        except ValueError:
            self.rebuild()

    # --- sterowanie ---------------------------------------------------------
    def play_index(self, index: int, autoplay: bool = True, position_ms: int = 0) -> None:
        if not (0 <= index < self._model.rowCount()):
            return

        self._current = index
        self._stream_mode = False
        track = self._model.track_at(index)
        if track is None:
            return

        self._model.set_current_path(track.path)
        self._sync_order_position()
        self.trackChanged.emit(track)

        if autoplay:
            self._engine.play_file(track.path)
        else:
            self._engine.load_file(track.path, position_ms)

    def play_first(self) -> None:
        if self._model.rowCount() > 0:
            self.play_index(0)

    def toggle(self) -> None:
        if self._current < 0:
            self.play_first()
            return
        if self._engine.is_playing():
            self._engine.pause()
        elif self._engine.has_source():
            self._engine.play()
        else:
            self.play_index(self._current)

    def stop(self) -> None:
        self._engine.stop()

    def next(self, auto: bool = False) -> None:
        count = self._model.rowCount()
        if count == 0:
            return
        if len(self._order) != count:
            self.rebuild()
        if not self._order:
            return

        if self._order_pos < 0:
            self._order_pos = 0
        next_pos = self._order_pos + 1
        if next_pos >= len(self._order):
            if auto and self._repeat == 0:
                self.stop()
                return
            next_pos = 0
        self.play_index(self._order[next_pos])

    def previous(self) -> None:
        # Jak w Winampie: najpierw wracamy na początek bieżącego utworu.
        if self._engine.position() > 3000:
            self._engine.seek(0)
            return
        count = self._model.rowCount()
        if count == 0:
            return
        if len(self._order) != count:
            self.rebuild()
        if not self._order:
            return

        prev_pos = self._order_pos - 1
        if prev_pos < 0:
            prev_pos = len(self._order) - 1
        self.play_index(self._order[prev_pos])

    def reset_current(self) -> None:
        """Czyści bieżący utwór (np. po usunięciu go z playlisty)."""
        if self._current < 0:
            return
        self._current = -1
        self._engine.stop()
        self._model.set_current_path(None)
        self.trackChanged.emit(None)

    def detach_stream(self) -> None:
        """Odpina bieżący utwór playlisty, ale NIE zatrzymuje silnika.

        Używane przy przejściu na radio: silnik ma od razu zagrać strumień,
        a playlista nie powinna dalej pokazywać starego utworu jako bieżącego.
        """
        self._current = -1
        self._order_pos = -1
        self._stream_mode = True
        self._model.set_current_path(None)
        self.trackChanged.emit(None)

    def prepare_removal(self, rows: set[int]) -> None:
        """Wywoływane PRZED usunięciem wierszy — poprawia indeks bieżącego utworu."""
        if self._current < 0:
            return
        if self._current in rows:
            self.reset_current()
        else:
            self._current -= sum(1 for row in rows if row < self._current)

    def _on_finished(self) -> None:
        # Strumień radiowy nie ma długości — jego zakończenie nie powinno
        # automatycznie włączać kolejnego utworu z playlisty.
        if self._stream_mode:
            return
        if self._repeat == 2:  # powtarzaj jeden utwór
            self._engine.seek(0)
            self._engine.play()
            return
        self.next(auto=True)
